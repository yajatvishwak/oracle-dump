import json
import pandas as pd
import os


class PayItemsExtractor:
    def __init__(self, file_location="", output_location="") -> None:
        self.data = json.load(open(file_location, "r"))
        if os.path.isdir(output_location):
            filename = (
                file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
                + ".csv"
            )
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def process_pay_items(self):
        result = []
        for contract in self.get_val(self.data, ["body"]):
            obj = {
                "Contract Item No.": "",
                "Contract Item Name": "",
                "Control Account (Code & Name)": "",
                "Control Element": "",
                "Financial Plan": "",
                "controlElementId": "",
                "Current Financial Plan": "",
                "Actuals YTD": "",
                "contractId": "",
                "controlAccountId": "",
                "controlElementCategoryId": "",
                "Remaining to spend": "",
                "Percent Invoiced": "",
                "id": "",
            }

            obj["Remaining to spend"] = self.get_val(
                contract, ["contractDetails", "remainingToSpend"]
            )
            obj["Percent Invoiced"] = self.get_val(
                contract, ["contractDetails", "percentInvoiced"]
            )
            obj["id"] = self.get_val(contract, ["shared", "id"])

            obj["Contract Item No."] = self.get_val(contract, ["shared", "code"])
            obj["Contract Item Name"] = self.get_val(contract, ["shared", "name"])

            obj["Control Account (Code & Name)"] = self.get_val(
                contract, ["controlAccountCode"]
            )
            obj["Control Element"] = self.get_val(
                contract, ["controlElementCategoryName"]
            )
            obj["Financial Plan"] = self.get_val(
                contract, ["contractDetails", "approvedAmount"]
            )
            obj["controlElementId"] = self.get_val(contract, ["controlElementId"])
            obj["Current Financial Plan"] = self.get_val(
                contract, ["contractDetails", "currentAmount"]
            )
            obj["Actuals YTD"] = self.get_val(
                contract, ["contractDetails", "approvedContractActuals"]
            )
            obj["contractId"] = self.get_val(contract, ["contractId"])
            obj["controlAccountId"] = self.get_val(contract, ["controlAccountId"])
            obj["controlElementCategoryId"] = self.get_val(
                contract, ["controlElementCategoryId"]
            )

            result.append(obj)
        df = pd.DataFrame.from_dict(result)
        df.to_csv(self.output_location, index=False)
        return True
