# fields_inspection.json

# item response trim till signature data
# area - areas[0].name, id

# obj = {
#     "region": "",
#     "project": "",
#     "Inspection Template": "",  # checklist x
#     "Title": "",  # checklist x
#     "Status": "",  # checklist x
#     "% Completed": "",  # checklist x
#     "Inspection No": "",  # checklist x
#     "Description": "",  # empty x
#     "Location": "",  # location x
#     "Created By": "",  # created_by x
#     "Created By Org": "",  # created_by x
#     "Date Created": "",  # created_at x
#     "Modified By": "",  # updated_by x
#     "Modified By Org": "",  # updated_by x
#     "Partner Agreement / Contract": "",  # items x
#     "Item No.": "",  # items x
#     "Implementer": "",  # items x
#     "Item Description": "",  # items x
#     "Item Response": "",  # items x
#     "Item Comment": "",  # items x
#     "Issue No.": "",  # items x
#     "Issue Status": "",  # items x
#     "Item Responded By": "",  # items x
#     "Date Item Responded": "",  # items
#     "Project ID": "",  # items x
#     "Short Name": "",  # items x
#     "Has Photo": "",  # items x
#     "Assigned to Org" : "" #items
# }


import json as json

import pandas as pd
import numpy as np
import os


class FieldInspectionExtractor:
    def __init__(self, file_location="", output_location=""):
        self.data = json.load(open(file_location, "r", encoding="utf-8"))
        filename = (
            file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
            + ".csv"
        )
        if os.path.isdir(output_location):
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location
        self.meta_output_location = os.path.join(output_location, f"meta_{filename}")

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def create_meta(self):
        d = {}
        d["results_on_page"] = self.get_val(self.data, ["results_on_page"])
        d["page_size"] = self.get_val(self.data, ["page_size"])
        d["page_number"] = self.get_val(self.data, ["page_number"])
        d["total_results"] = self.get_val(self.data, ["total_results"])
        d["total_pages"] = self.get_val(self.data, ["total_pages"])

        df = pd.DataFrame.from_dict([d])
        df.to_csv(self.meta_output_location, index=False)
        return True

    def substring_until_word(self, input_string, target_word):
        try:
            index = input_string.find(target_word)
            if index != -1:
                return input_string[:index]
            else:
                return input_string
        except ValueError:
            return ""

    def process_checklists(self):
        result = []
        try:
            for checklist in self.data["checklists"]:
                obj = {
                    "region": "",
                    "project": "",
                    "Project ID": "",
                    "Short Name": "",
                    "Inspection Template": "",  # checklist
                    "Title": "",  # checklist
                    "Status": "",  # checklist
                    "Percent Completed": "",  # checklist
                    "Inspection No": "",  # checklist
                    "Description": "",  # empty
                    "Location": "",  # location
                    "Created By": "",  # created_by
                    "Created By Org": "",  # created_by
                    "Date Created": "",  # created_at
                    "Modified By": "",  # updated_by
                    "Modified By Org": "",  # updated_by
                    "Partner Agreement / Contract": "",  # items
                    "Item No.": "",  # items
                    "Implementer": "",  # items
                    "Item Description": "",  # items
                    "Item Response": "",  # items
                    "Item Comment": "",  # items
                    "Issue No.": "",  # items
                    "Issue Status": "",  # items
                    "Item Responded By": "",  # items
                    "Date Item Responded": "",  # items
                    "Project ID": "",  # items
                    "Short Name": "",  # items
                    "Has Photo": "",  # items
                    "Assigned to Org": "",  # items
                }

                obj["Inspection Template"] = self.get_val(checklist, ["template_title"])
                obj["Inspection No"] = self.get_val(checklist, ["number"])
                obj["Title"] = self.get_val(checklist, ["title"])
                obj["Status"] = self.get_val(checklist, ["status"])
                obj["Percent Completed"] = self.get_val(
                    checklist, ["percentage_completed"]
                )

                obj["Location"] = "->".join(
                    self.get_val(path, ["name"])
                    for path in self.get_val(checklist, ["area", "path"])
                )
                obj["Created By"] = (
                    self.get_val(checklist, ["meta_data", "created_by", "first_name"])
                    + " "
                    + self.get_val(checklist, ["meta_data", "created_by", "last_name"])
                )
                obj["Created By Org"] = self.get_val(
                    checklist, ["meta_data", "created_by", "organization", "name"]
                )
                obj["Date Created"] = self.get_val(
                    checklist, ["meta_data", "created_at"]
                )
                obj["Modified By"] = (
                    self.get_val(checklist, ["meta_data", "updated_by", "first_name"])
                    + " "
                    + self.get_val(checklist, ["meta_data", "updated_by", "last_name"])
                )
                obj["Modified By Org"] = self.get_val(
                    checklist, ["meta_data", "updated_by", "organization", "name"]
                )
                obj["Project ID"] = self.get_val(checklist, ["project", "id"])
                obj["Short Name"] = self.get_val(checklist, ["project", "short_name"])
                obj["Assigned to Org"] = self.get_val(checklist, ["assignments"])
                if (
                    isinstance(obj["Assigned to Org"], list)
                    and len(obj["Assigned to Org"]) > 0
                ):
                    obj["Assigned to Org"] = self.get_val(
                        obj["Assigned to Org"][0], ["assigned_to_org", "name"]
                    )
                else:
                    obj["Assigned to Org"] = ""

                for item in self.get_val(checklist, ["items"]):
                    obj1 = obj.copy()
                    obj1["Item Description"] = self.get_val(item, ["description"])
                    # print("bc", obj1["Item Description"])
                    obj1["Item Response"] = self.get_val(item, ["response", "value"])
                    obj1["Item Response"] = self.substring_until_word(
                        obj1["Item Response"], "data:image"
                    )
                    obj1["Item Comment"] = self.get_val(item, ["comment"])
                    obj1["Item No."] = self.get_val(item, ["item_number"])
                    obj1["Date Item Responded"] = self.get_val(
                        item, ["response", "responded_at"]
                    )
                    obj1["Item Responded By"] = (
                        self.get_val(item, ["response", "responded_by", "first_name"])
                        + " "
                        + self.get_val(item, ["response", "responded_by", "last_name"])
                    )
                    # obj1["Project ID"] = get_val(item, ["project", "id"])
                    # print("bhai", obj1["Project ID"])

                    # obj1["Short Name"] = get_val(item, ["project", "short_name"])
                    obj1["Implementer"] = (
                        self.get_val(item, ["response", "value"])
                        if self.get_val(item, ["description"]) == "Implementer"
                        else ""
                    )
                    obj1["Partner Agreement / Contract"] = (
                        self.get_val(item, ["response", "value"])
                        if self.get_val(item, ["description"])
                        == "Partner Agreement / Contract"
                        else ""
                    )
                    obj1["Issue No."] = self.get_val(item, ["issue", "issue_number"])
                    obj1["Issue Status"] = self.get_val(item, ["issue", "status"])
                    if (
                        self.get_val(item, ["photo_url"]) == ""
                        or self.get_val(item, ["photo_url"]) == "null"
                        or self.get_val(item, ["photo_url"]) == None
                    ):
                        obj1["Has Photo"] = "N"
                    else:
                        obj1["Has Photo"] = "Y"
                    result.append(obj1)

                for group in self.get_val(checklist, ["groups"]):
                    for item2 in self.get_val(group, ["items"]):
                        obj2 = obj.copy()
                        obj2["Item Description"] = self.get_val(item2, ["description"])
                        obj2["Item Response"] = self.get_val(
                            item2, ["response", "value"]
                        )
                        obj2["Item Response"] = self.substring_until_word(
                            obj2["Item Response"], "data:image"
                        )
                        obj2["Item Comment"] = self.get_val(item2, ["comment"])
                        obj2["Item No."] = self.get_val(item2, ["item_number"])
                        obj2["Item Responded By"] = (
                            self.get_val(
                                item2, ["response", "responded_by", "first_name"]
                            )
                            + " "
                            + self.get_val(
                                item2, ["response", "responded_by", "last_name"]
                            )
                        )
                        obj2["Date Item Responded"] = self.get_val(
                            item2, ["response", "responded_at"]
                        )
                        obj2["Implementer"] = (
                            self.get_val(item2, ["response", "value"])
                            if self.get_val(item2, ["description"]) == "Implementer"
                            else ""
                        )
                        obj2["Partner Agreement / Contract"] = (
                            self.get_val(item2, ["response", "value"])
                            if self.get_val(item2, ["description"])
                            == "Partner Agreement / Contract"
                            else ""
                        )
                        obj2["Issue No."] = self.get_val(
                            item2, ["issue", "issue_number"]
                        )
                        obj2["Issue Status"] = self.get_val(item2, ["issue", "status"])
                        if (
                            self.get_val(item2, ["photo_url"]) == ""
                            or self.get_val(item2, ["photo_url"]) == "null"
                            or self.get_val(item2, ["photo_url"]) == None
                        ):
                            obj2["Has Photo"] = "N"
                        else:
                            obj2["Has Photo"] = "Y"
                        result.append(obj2)

            df = pd.DataFrame.from_dict(result)
            df = df.drop_duplicates()

            df.to_csv(self.output_location, index=False, encoding="utf-8-sig")

            return True
        except Exception as e:
            raise e


# f = FieldInspectionExtractor(file_location="old.json", output_location="")
# if f.process_checklists():
#     print("Processed")
