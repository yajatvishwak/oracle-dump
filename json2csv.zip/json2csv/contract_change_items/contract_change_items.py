import json
import pandas as pd
import os


class ContractChangeItemsExtractor:
    def __init__(self, file_location="", output_location="") -> None:
        self.data = json.load(open(file_location, "r"))
        if os.path.isdir(output_location):
            filename = (
                file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
                + ".csv"
            )
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def process_contract_change_items(self):
        result = []
        for contract in self.get_val(self.data, ["body"]):
            obj = {
                "Accepted Amount": "",
                "contract_id": "",
                "control_element_id": "",
                "control_account_id": "",
                "control_element_category_id": "",
                "id": "",
                "contract_change_orders_id": "",
                "sharedId": "",
            }
            obj["Accepted Amount"] = self.get_val(
                contract, ["shared", "acceptedAmount"]
            )
            obj["contract_id"] = self.get_val(contract, ["payItem", "contractId"])
            obj["control_element_id"] = self.get_val(
                contract, ["payItem", "controlElementId"]
            )
            obj["control_account_id"] = self.get_val(
                contract, ["payItem", "controlAccountId"]
            )
            obj["control_element_category_id"] = self.get_val(
                contract, ["payItem", "controlElementCategoryId"]
            )
            obj["contract_change_orders_id"] = self.get_val(
                contract, ["contractChangeOrderId"]
            )
            obj["id"] = self.get_val(contract, ["id"])
            obj["sharedId"] = self.get_val(contract, ["payItem", "shared", "id"])

            result.append(obj)
        df = pd.DataFrame.from_dict(result)
        df.to_csv(self.output_location, index=False)
        return True
