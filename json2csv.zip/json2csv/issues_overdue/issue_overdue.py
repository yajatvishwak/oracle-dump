import pandas as pd
import os
import json


class IssueOverdueExtractor:
    def __init__(
        self, file_location="", output_location="", custom_field_file_location=""
    ):
        self.data = json.load(open(file_location, "r"))
        self.custom_fields_data = json.load(open(custom_field_file_location, "r"))
        filename = (
            file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
            + ".csv"
        )
        if os.path.isdir(output_location):
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location
        self.meta_output_location = os.path.join(output_location, f"meta_{filename}")

    def create_meta(self):
        d = {}
        d["results_on_page"] = self.get_val(self.data, ["results_on_page"])
        d["page_size"] = self.get_val(self.data, ["page_size"])
        d["page_number"] = self.get_val(self.data, ["page_number"])
        d["total_results"] = self.get_val(self.data, ["total_results"])
        d["total_pages"] = self.get_val(self.data, ["total_pages"])

        df = pd.DataFrame.from_dict([d])
        df.to_csv(self.meta_output_location, index=False)
        return True

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def parse_custom_fields(self):
        result = {}
        for customfield in self.get_val(self.custom_fields_data, ["custom_fields"]):
            family_id = self.get_val(customfield, ["family_id"])
            if family_id:
                result[family_id] = self.get_val(customfield, ["label"])

        return result

    def process_issue_overdue(self):
        result = []
        custom_fields = self.parse_custom_fields()

        label = self.get_val(custom_fields, ["Partner Agreement / Contract"])

        for response in self.get_val(self.data, ["issues"]):
            obj = {
                "Region": "",
                "Project/ABC": "",
                "Partner Agreement / Contract": "",
                "Assigned to Organisation": "",
                "Assigned to User": "",
                "Open": "",
                "projectid": "",
                "issue_id": "",
                "issue_number": "",
                "area_id": "",
                "Implementer": "",
            }
            if "assigned_to" in response and "organization" in response["assigned_to"]:
                obj["Assigned to Organisation"] = self.get_val(
                    response, ["assigned_to", "organization", "name"]
                )
            else:
                obj["Assigned to Organisation"] = "Unassigned"

            if "assigned_to" in response and "user" in response["assigned_to"]:
                obj["Assigned to User"] = (
                    self.get_val(response, ["assigned_to", "user", "first_name"])
                    + " "
                    + self.get_val(response, ["assigned_to", "user", "last_name"])
                )

            obj["projectid"] = self.get_val(response, ["project", "id"])
            obj["issue_id"] = self.get_val(response, ["issue_id"])
            obj["issue_number"] = self.get_val(response, ["issue_number"])
            obj["area_id"] = self.get_val(response, ["area", "id"])
            # obj["Partner Agreement / Contract"] = self.get_val(
            #     custom_fields, ["Partner Agreement / Contract"]
            # )
            for custom in self.get_val(response, ["custom_fields"]):
                family_id = self.get_val(custom, ["family_id"])
                value = self.get_val(custom, ["value"])
                label = self.get_val(custom_fields, [family_id])
                obj1 = obj.copy()
                if label in obj1 and label == "Partner Agreement / Contract":
                    obj1[label] = value
                if label in obj1 and label == "Implementer":
                    obj1[label] = value
                result.append(obj1)
            result.append(obj)
        df = pd.DataFrame.from_dict(result)
        df.to_csv(
            self.output_location,
            index=False,
        )
        return True
