from utils.gomma import parse
import pandas as pd
import os
from pprint import pprint


class MailInboxExtractor:
    def __init__(
        self,
        output_location,
        file_location="",
    ) -> None:
        self.data = parse(open(file_location, "r").read())
        filename = (
            file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
            + ".csv"
        )
        if os.path.isdir(output_location):
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location
        self.meta_output_location = os.path.join(output_location, f"meta_{filename}")

    def create_meta(self):
        d = {}
        d["TotalResultsOnPage"] = self.get_val(
            self.data, ["MailSearch", "@TotalResultsOnPage"]
        )
        d["TotalResults"] = self.get_val(self.data, ["MailSearch", "@TotalResults"])
        d["TotalResultsOnPage"] = self.get_val(
            self.data, ["MailSearch", "@TotalResultsOnPage"]
        )
        d["TotalPages"] = self.get_val(self.data, ["MailSearch", "@TotalPages"])
        d["PageSize"] = self.get_val(self.data, ["MailSearch", "@PageSize"])
        d["CurrentPage"] = self.get_val(self.data, ["MailSearch", "@CurrentPage"])

        df = pd.DataFrame.from_dict([d])
        df.to_csv(self.meta_output_location, index=False)
        return True

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def count_name(self, target_name):
        count = 0
        if isinstance(
            self.get_val(self.data, ["MailSearch", "SearchResults", "Mail"]), dict
        ):
            mail = self.get_val(self.data, ["MailSearch", "SearchResults", "Mail"])
            name = self.get_val(mail, ["ToUsers", "Recipient", "Name"])
            status = self.get_val(mail, ["ToUsers", "Recipient", "Status"])
            if name == target_name and status == "Overdue":  # counting overdue
                count += 1
            print(f"For name {target_name} count {count}")
            return count

        elif isinstance(
            self.get_val(self.data, ["MailSearch", "SearchResults", "Mail"]), list
        ):
            for mail in self.get_val(
                self.data, ["MailSearch", "SearchResults", "Mail"]
            ):
                if isinstance(self.get_val(mail, ["ToUsers", "Recipient"]), list):
                    for recipient in self.get_val(mail, ["ToUsers", "Recipient"]):
                        name = self.get_val(recipient, ["Name"])
                        status = self.get_val(recipient, ["Status"])

                        if (
                            name == target_name and status == "Overdue"
                        ):  # counting overdue
                            count += 1
                elif isinstance(self.get_val(mail, ["ToUsers", "Recipient"]), dict):
                    # print(mail)
                    name = self.get_val(mail, ["ToUsers", "Recipient", "Name"])
                    status = self.get_val(mail, ["ToUsers", "Recipient", "Status"])

                    if name == target_name and status == "Overdue":
                        count += 1
            print(f"For name {target_name} count {count}")
            return count
        return -1

    def process_mailinbox(self):
        try:
            result = []
            adata = self.get_val(self.data, ["MailSearch", "SearchResults", "Mail"])
            # #print(len(self.get_val(self.data, ["MailSearch", "SearchResults", "Mail"])))
            if isinstance(adata, list):
                for mail in adata:
                    # type, review status
                    obj = {
                        "Region": "",
                        "Project/ABC": "",
                        "Partner Agreement / Contract": "",
                        "Recipient Organisation": "",
                        "Recipients": "",
                        "Overdue": "",
                        "MailId": "",
                    }
                    obj["MailId"] = self.get_val(mail, ["@MailId"])
                    if isinstance(self.get_val(mail, ["ToUsers", "Recipient"]), list):
                        for recipient in self.get_val(mail, ["ToUsers", "Recipient"]):
                            obj1 = obj.copy()
                            obj1["Recipient Organisation"] = self.get_val(
                                recipient, ["OrganizationName"]
                            )
                            obj1["Recipients"] = (
                                self.get_val(recipient, ["FirstName"])
                                + " "
                                + self.get_val(recipient, ["LastName"])
                            )
                            obj1["Overdue"] = self.count_name(
                                self.get_val(recipient, ["Name"])
                            )
                            result.append(obj1)
                    elif isinstance(self.get_val(mail, ["ToUsers", "Recipient"]), dict):
                        obj["Recipient Organisation"] = self.get_val(
                            mail, ["ToUsers", "Recipient", "OrganizationName"]
                        )
                        obj["Recipients"] = (
                            self.get_val(mail, ["ToUsers", "Recipient", "FirstName"])
                            + " "
                            + self.get_val(mail, ["ToUsers", "Recipient", "LastName"])
                        )
                        obj["Overdue"] = self.count_name(
                            self.get_val(mail, ["ToUsers", "Recipient", "Name"])
                        )
                        result.append(obj)
            elif isinstance(adata, dict):
                obj = {
                    "Region": "",
                    "Project/ABC": "",
                    "Partner Agreement / Contract": "",
                    "Recipient Organisation": "",
                    "Recipients": "",
                    "Overdue": "",
                    "MailId": "",
                }
                obj["MailId"] = self.get_val(adata, ["@MailId"])
                obj["Overdue"] = self.count_name(
                    self.get_val(adata, ["ToUsers", "Recipient", "Name"])
                )
                obj["Recipient Organisation"] = self.get_val(
                    adata, ["ToUsers", "Recipient", "OrganizationName"]
                )
                obj["Recipients"] = (
                    self.get_val(adata, ["ToUsers", "Recipient", "FirstName"])
                    + " "
                    + self.get_val(adata, ["ToUsers", "Recipient", "LastName"])
                )
                result.append(obj)

            df = pd.DataFrame.from_dict(result)
            df = df.drop_duplicates()
            df.to_csv(self.output_location, index=False)
            return True
        except Exception as e:
            raise e
