import os
import json
import pandas as pd


class ContractChangeExtractor:
    def __init__(self, file_location="", output_location=""):
        self.data = json.load(open(file_location, "r"))
        if os.path.isdir(output_location):
            filename = (
                file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
                + ".csv"
            )
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

    def get_val(self, dict, keys):
        try:
            if isinstance(dict, str):
                return ""
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def process_contract_change(self):
        try:
            result = []
            for element in self.get_val(self.data, ["body"]):
                obj = {
                    "project_id": "",
                    "contract_id": "",
                    "Approved Changes": "",
                    "Approved Amount": "",
                    "Amendments": "",
                    "Reallocations": "",
                    "Agreement Name": "",
                    "Partner Agreement / Contract": "",
                    "Implementer": "",
                    "Variation No": "",
                    "Variation Name": "",
                    "Variation Type": "",
                    "Currency": "",
                    "Approved Date": "",
                    "Accepted": "",
                    "Category Name": "",
                    "Name": "",
                    "id": "",
                }
                obj["id"] = self.get_val(element, ["id"])
                obj["project_id"] = self.get_val(element, ["projectId"])
                obj["contract_id"] = self.get_val(element, ["contractId"])
                obj["Approved Changes"] = self.get_val(
                    element, ["contractDetails", "approvedChanges"]
                )
                obj["Approved Amount"] = self.get_val(
                    element, ["contractDetails", "approvedAmount"]
                )
                obj["Amendments"] = ""
                obj["Reallocations"] = ""
                obj["Agreement Name"] = self.get_val(element, ["contractName"])
                obj["Partner Agreement / Contract"] = self.get_val(
                    element, ["shared", "sharedContractCode"]
                )
                obj["Implementer"] = self.get_val(element, ["partnerEnterpriseName"])
                obj["Variation No"] = self.get_val(element, ["shared", "code"])
                obj["Variation Name"] = self.get_val(element, ["shared", "name"])
                obj["Currency"] = self.get_val(element, ["shared", "currency"])
                obj["Approved Date"] = self.get_val(element, ["shared", "approvedDate"])
                obj["Accepted"] = self.get_val(
                    element, ["contractDetails", "approvedAmount"]
                )
                # obj["Accepted Amount"] = self.get_val(element, [""])
                if len(self.get_val(element, ["tags"])) <= 0:
                    result.append(obj)
                else:
                    for tag in self.get_val(element, ["tags"]):
                        # print(tag, self.get_val(tag, ))
                        obj1 = obj.copy()
                        obj1["Category Name"] = self.get_val(tag, ["categoryName"])
                        obj1["Name"] = self.get_val(tag, ["name"])
                        if self.get_val(tag, ["categoryName"]) == "Variation Type":
                            obj1["Variation Type"] = self.get_val(tag, ["name"])
                        result.append(obj1)

            df = pd.DataFrame.from_dict(result)
            df = df.drop_duplicates()
            df.to_csv(
                self.output_location,
                index=False,
            )
            return True
        except Exception as e:
            raise e


# p = ContractChangeExtractor(
#     file_location="contract_change.json",
#     output_location="",
# )
# if p.process_contract_change():
#     print("Processed")
