# xml file - project

# project_id
# project_short_name


from utils.gomma import parse
import pandas as pd
import os


class DocumentsExtractor:
    def __init__(
        self,
        output_location,
        file_location="",
    ) -> None:
        self.data = parse(open(file_location, "r").read())
        filename = (
            file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
            + ".csv"
        )
        if os.path.isdir(output_location):
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location
        self.meta_output_location = os.path.join(output_location, f"meta_{filename}")

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def create_meta(self):
        d = {}

        d["TotalResultsOnPage"] = self.get_val(
            self.data, ["RegisterSearch", "@TotalResultsOnPage"]
        )
        d["TotalResults"] = self.get_val(self.data, ["RegisterSearch", "@TotalResults"])
        d["TotalPages"] = self.get_val(self.data, ["RegisterSearch", "@TotalPages"])
        d["PageSize"] = self.get_val(self.data, ["RegisterSearch", "@PageSize"])
        d["CurrentPage"] = self.get_val(self.data, ["RegisterSearch", "@CurrentPage"])

        df = pd.DataFrame.from_dict([d])
        df.to_csv(self.meta_output_location, index=False)
        return True

    def process_documents(self):
        try:
            print(self.data)
            result = []
            for document in self.get_val(
                self.data, ["RegisterSearch", "SearchResults", "Document"]
            ):
                # type, review status
                obj = {
                    "DocumentNumber": "",
                    "DocumentType": "",
                    "Implementer_singleSelect": "",
                    "TrackingId": "",
                    "DocumentId": "",
                    "PartnerAgreementContract_singleSelect": "",
                }
                obj["DocumentNumber"] = self.get_val(document, ["DocumentNumber"])
                obj["DocumentType"] = self.get_val(document, ["DocumentType"])
                obj["PartnerAgreementContract_singleSelect"] = self.get_val(
                    document, ["PartnerAgreementContract_singleSelect"]
                )
                obj["Implementer_singleSelect"] = self.get_val(
                    document, ["Implementer_singleSelect"]
                )
                obj["TrackingId"] = self.get_val(document, ["TrackingId"])
                obj["DocumentId"] = self.get_val(document, ["@DocumentId"])

                result.append(obj)
            # print(self.data)

            df = pd.DataFrame.from_dict(result)
            df = df.drop_duplicates()
            df.to_csv(self.output_location, index=False)
            return True
        except Exception as e:
            raise e
