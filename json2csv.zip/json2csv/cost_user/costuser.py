import pandas as pd
import os
import json


class CostUserExtractor:
    def __init__(
        self,
        file_location="",
        output_location="",
    ):
        self.data = json.load(open(file_location, "r"))
        if os.path.isdir(output_location):
            filename = (
                file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
                + ".csv"
            )
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def process_cost_user(self):
        result = []
        for response in self.get_val(self.data, ["body"]):
            obj = {
                "First Name": "",
                "id": "",
                "Surname": "",
                "Project": "",
                "Security Profile": "",
                "securityProfileId": "",
                "aconexId": "",
            }
            obj["First Name"] = self.get_val(response, ["firstName"])
            obj["Surname"] = self.get_val(response, ["lastName"])
            obj["id"] = self.get_val(response, ["id"])
            obj["aconexId"] = self.get_val(response, ["aconexId"])
            obj["securityProfileId"] = self.get_val(response, ["securityProfileId"])

            result.append(obj)
        df = pd.DataFrame.from_dict(result)
        df.to_csv(
            self.output_location,
            index=False,
        )
        return True
