import pandas as pd
import os
import json


class CostExcludeProjectsExtractor:
    def __init__(
        self,
        file_location="",
        output_location="",
    ):
        self.data = json.load(open(file_location, "r"))
        if os.path.isdir(output_location):
            filename = (
                file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
                + ".csv"
            )
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def process_cost_exclude(self):
        result = []
        for response in self.get_val(self.data, ["body"]):
            obj = {
                "Project": "",
                "Security Profile": "",
                "OBS Assignment": "",
                "Access to Cost Project": "",
                "Reason": "",
                "id": "",
                "aconexId": "",
                "securityProfileId": "",
                "ProjectId": "",
            }
            obj["Project"] = self.get_val(response, ["project", "shortName"])
            obj["Security Profile"] = self.get_val(
                response, ["user", "securityProfileName"]
            )
            obj["OBS Assignment"] = self.get_val(response, ["user", "obsAssignments"])
            obj["Access to Cost Project"] = self.get_val(response, ["access"])
            obj["Reason"] = self.get_val(response, ["reason"])
            obj["id"] = self.get_val(response, ["user", "id"])
            obj["aconexId"] = self.get_val(response, ["user", "aconexId"])
            obj["securityProfileId"] = self.get_val(
                response, ["user", "securityProfileId"]
            )
            obj["ProjectId"] = self.get_val(response, ["project", "aconexId"])

            result.append(obj)
        df = pd.DataFrame.from_dict(result)
        df.to_csv(
            self.output_location,
            index=False,
        )
        return True
