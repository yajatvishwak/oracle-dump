import os
import json
import csv
import pandas as pd


class CostElementsExtractor:
    def __init__(self, file_location="", output_location=""):
        self.data = json.load(open(file_location, "r"))
        if os.path.isdir(output_location):
            filename = (
                file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
                + ".csv"
            )
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

    def get_val(self, dict, keys):
        try:
            if isinstance(dict, str):
                return ""
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def process_control_elements(self):
        try:
            result = []
            for element in self.get_val(self.data, ["body"]):
                obj = {
                    "project_id": "",
                    "control_account_id": "",
                    "control_element_category_id": "",
                    "Expenditure Type": "",
                    "Financial Plan": "",
                    "Amendments/Reallocations": "",
                    # "Reallocations": "",
                    # "Amendments": "",
                    "Current Financial Plan": "",
                    "Actuals YTD": "",
                    "Remaining To Spend": "",
                    "Remaining Installments": "",
                    "id": "",
                }
                obj["id"] = self.get_val(element, ["id"])
                obj["project_id"] = self.get_val(element, ["projectId"])
                obj["control_account_id"] = self.get_val(element, ["controlAccountId"])
                obj["control_element_category_id"] = self.get_val(
                    element, ["controlElementCategory", "id"]
                )

                obj["Expenditure Type"] = self.get_val(
                    element, ["controlElementCategory", "name"]
                )
                obj["Financial Plan"] = self.get_val(
                    element, ["contractDetails", "approvedAmount"]
                )
                obj["Amendments/Reallocations"] = self.get_val(
                    element, ["contractDetails", "approvedChanges"]
                )
                obj["Current Financial Plan"] = self.get_val(
                    element, ["contractDetails", "currentAmount"]
                )
                obj["Actuals YTD"] = self.get_val(
                    element, ["contractDetails", "approvedContractActuals"]
                )
                obj["Remaining To Spend"] = self.get_val(
                    element, ["contractDetails", "remainingToSpend"]
                )
                obj["Remaining Installments"] = self.get_val(
                    element, ["contractDetails", "approvedContractActuals"]
                )
                if obj["Remaining Installments"] != "":
                    obj["Remaining Installments"] *= -1

                result.append(obj)

            df = pd.DataFrame.from_dict(result)
            df = df.drop_duplicates()
            df.to_csv(self.output_location, index=False, quoting=csv.QUOTE_NONNUMERIC)
            return True
        except Exception as e:
            raise e


# p = CostElementsExtractor(
#     contract_location="contract_change.json",
#     element_response_location="control_elements.json",
#     output_location="",
# )
# if p.process_cost():
#     print("Processed")
