import pandas as pd
import os
import json


class CostSecurityProfileExtractor:
    def __init__(
        self,
        file_location="",
        output_location="",
    ):
        self.data = json.load(open(file_location, "r"))
        if os.path.isdir(output_location):
            filename = (
                file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
                + ".csv"
            )
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def process_cost_security_profile(self):
        result = []
        for response in self.get_val(self.data, ["body"]):
            obj = {
                "securityProfileId": "",
                "name": "",
            }
            obj["name"] = self.get_val(response, ["name"])
            obj["securityProfileId"] = self.get_val(response, ["id"])

            result.append(obj)
        df = pd.DataFrame.from_dict(result)
        df.to_csv(
            self.output_location,
            index=False,
        )
        return True
