import pandas as pd
import os
import json


class WBSContractExtractor:
    def __init__(
        self,
        file_location="",
        output_location="",
    ):
        self.data = json.load(open(file_location, "r"))
        if os.path.isdir(output_location):
            filename = (
                file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
                + ".csv"
            )
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def traverse_children(
        self, node, current_level=0, target_level=2, selected_fields=None, result=None
    ):
        if result is None:
            result = []  # Initialize the result list

        # Check if the current level is equal to the target level
        if current_level == target_level:
            if selected_fields is None:
                selected_fields = (
                    []
                )  # If no fields are specified, select all available fields
            node_data = {field: node.get(field) for field in selected_fields}
            result.append(node_data)

        # Check if the node has children
        if "children" in node:
            # Increment the level and loop through the children list
            for child in node["children"]:
                # Call the function recursively for each child
                self.traverse_children(
                    child, current_level + 1, target_level, selected_fields, result
                )

        return result  # Return the collected data

    def process_contracts_response(self):
        result = []
        for response in self.get_val(self.data, ["body"]):
            obj = {
                "project_id": "",
                "id": "",
                "Shared_code": "",
                "Shared_currency": "",
                "Contract_Status": "",
                "Financial Plan": "",
                "Amendments/Reallocations": "",
                "Current Financial Plan": "",
                "Actuals YTD": "",
                "Remaining to Spend": "",
                "Percent Invoiced": "",
                "partnerEnterpriseName": "",
                "Agreement Name": "",
            }
            obj["project_id"] = self.get_val(response, ["projectId"])
            obj["id"] = self.get_val(response, ["id"])
            obj["Shared_code"] = self.get_val(response, ["shared", "code"])
            obj["Shared_currency"] = self.get_val(response, ["shared", "currency"])
            obj["Contract_Status"] = self.get_val(response, ["shared", "status"])
            obj["Agreement Name"] = self.get_val(response, ["shared", "name"])
            obj["Financial Plan"] = self.get_val(
                response, ["contractDetails", "approvedAmount"]
            )
            obj["Amendments/Reallocations"] = self.get_val(
                response, ["contractDetails", "approvedChanges"]
            )
            obj["Current Financial Plan"] = self.get_val(
                response, ["contractDetails", "currentAmount"]
            )
            obj["Actuals YTD"] = self.get_val(
                response, ["contractDetails", "approvedContractActuals"]
            )
            obj["Remaining to Spend"] = self.get_val(
                response, ["contractDetails", "remainingToSpend"]
            )
            obj["Percent Invoiced"] = self.get_val(
                response, ["contractDetails", "percentInvoiced"]
            )
            obj["partnerEnterpriseName"] = self.get_val(
                response, ["partnerEnterpriseName"]
            )

            result.append(obj)
        df = pd.DataFrame.from_dict(result)
        df.to_csv(
            self.output_location,
            index=False,
        )
        return True


# w = WBSExtractor(
#     wbs_file_location="WBS_response.json",
#     contract_response_location="contracts_response.json",
#     accounts_response_location="Control_accounts_response.json",
#     output_location="",
# )
# w.process_wbs()
# print(w.parse_accounts_response())
# w.process_accounts_response()
# w.process_contracts_response()
