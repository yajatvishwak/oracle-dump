# xml file - project

# project_id
# project_short_name


from utils.gomma import parse
import pandas as pd
import os


class WorkflowExtractor:
    def __init__(
        self,
        output_location,
        file_location="",
    ) -> None:
        self.data = parse(open(file_location, "r").read())
        filename = (
            file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
            + ".csv"
        )
        if os.path.isdir(output_location):
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

        self.meta_output_location = os.path.join(output_location, f"meta_{filename}")

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def create_meta(self):
        d = {}

        d["TotalResultsOnPage"] = self.get_val(
            self.data, ["WorkflowSearch", "@TotalResultsOnPage"]
        )
        d["TotalResults"] = self.get_val(self.data, ["WorkflowSearch", "@TotalResults"])
        d["TotalPages"] = self.get_val(self.data, ["WorkflowSearch", "@TotalPages"])
        d["PageSize"] = self.get_val(self.data, ["WorkflowSearch", "@PageSize"])
        d["CurrentPage"] = self.get_val(self.data, ["WorkflowSearch", "@CurrentPage"])

        df = pd.DataFrame.from_dict([d])
        df.to_csv(self.meta_output_location, index=False)
        return True

    def process_workflows(self):
        try:
            result = []
            for workflow in self.get_val(
                self.data, ["WorkflowSearch", "SearchResults", "Workflow"]
            ):
                # type, review status
                obj = {
                    "Region": "",
                    "Project/ABC": "",
                    "Partner Agreement / Contract": "",
                    "Implementer": "",
                    "DocumentTrackingId": "",
                    "Template": "",
                    "Workflow No": "",
                    "Document No": "",
                    "Workflow Status": "",
                    "Document Title": "",
                    "Type": "",
                    "Revision": "",
                    "Version": "",
                    "Review Status": "",
                    "Step Name": "",
                    "Assigned To Organization": "",
                    "Assigned To": "",
                    "Step Status": "",
                    "Date Due": "",
                    "Step Outcome": "",
                    "Days Late": "",
                    "Initiator Name": "",
                    "Initiator Org Name": "",
                }
                obj["DocumentTrackingId"] = self.get_val(
                    workflow, ["DocumentTrackingId"]
                )
                obj["Template"] = self.get_val(workflow, ["WorkflowTemplate"])
                obj["Workflow Status"] = self.get_val(workflow, ["WorkflowStatus"])
                obj["Workflow No"] = self.get_val(workflow, ["WorkflowNumber"])
                obj["Document No"] = self.get_val(workflow, ["DocumentNumber"])
                obj["Document Title"] = self.get_val(workflow, ["DocumentTitle"])
                obj["Revision"] = self.get_val(workflow, ["DocumentRevision"])
                obj["Version"] = self.get_val(workflow, ["DocumentVersion"])
                obj["Step Name"] = self.get_val(workflow, ["StepName"])
                obj["Document Title"] = self.get_val(workflow, ["DocumentTitle"])
                # obj["Assigned To Organization"] = self.get_val(
                #     workflow, ["Reviewer", "OrganizationName"]
                # )
                # obj["Assigned To"] = self.get_val(workflow, ["Reviewer", "Name"])
                obj["Assigned To Organization"] = self.get_val(
                    workflow, ["Assignees", "Assignee", "OrganizationName"]
                )
                obj["Assigned To"] = self.get_val(
                    workflow, ["Assignees", "Assignee", "Name"]
                )
                obj["Step Status"] = self.get_val(workflow, ["StepStatus"])
                obj["Step Outcome"] = self.get_val(workflow, ["StepOutcome"])
                obj["Days Late"] = self.get_val(workflow, ["DaysLate"])
                obj["Date Due"] = self.get_val(workflow, ["DateDue"])
                obj["Initiator Name"] = self.get_val(workflow, ["Initiator", "Name"])
                obj["Initiator Org Name"] = self.get_val(
                    workflow, ["Initiator", "OrganizationName"]
                )

                result.append(obj)
            # print(self.data)

            df = pd.DataFrame.from_dict(result)
            df = df.drop_duplicates()
            df.to_csv(self.output_location, index=False)
            return True
        except Exception as e:
            raise e
