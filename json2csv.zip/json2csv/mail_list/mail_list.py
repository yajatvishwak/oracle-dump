# xml file - project

# project_id
# project_short_name


from utils.gomma import parse
import pandas as pd
import os


class MailListExtractor:
    def __init__(
        self,
        output_location,
        file_location="",
    ) -> None:
        self.data = parse(open(file_location, "r").read())
        if os.path.isdir(output_location):
            filename = (
                file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
                + ".csv"
            )
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def process_maillist(self):
        try:
            result = []
            # type, review status
            obj = {"Identifier": "", "Value": "", "MailId": "", "MailType": ""}
            obj["MailId"] = self.get_val(self.data, ["Mail", "@MailId"])
            obj["MailType"] = self.get_val(self.data, ["Mail", "CorrespondenceType"])
            print(obj)
            print(self.get_val(self.data, ["Mail", "CustomFields", "CustomField"]))
            if self.get_val(self.data, ["Mail", "CustomFields", "CustomField"]):
                for custom in self.get_val(
                    self.data, ["Mail", "CustomFields", "CustomField"]
                ):
                    obj1 = obj.copy()
                    # print(custom)
                    obj1["Value"] = self.get_val(custom, ["Value"])
                    obj1["Identifier"] = self.get_val(custom, ["Identifier"])
                    print(obj1)
                    result.append(obj1)
            else:
                result.append(obj)
                print(obj)

            df = pd.DataFrame.from_dict(result)
            df = df.drop_duplicates()
            df.to_csv(self.output_location, index=False)
            return True
        except Exception as e:
            raise e
