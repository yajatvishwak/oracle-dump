# cost eps.json

# Region - 1 child.name
# project - child.child[xn].shortname
# acconex - child.child[xn].acconexid
# child_project_id = child.child[xn].id
# primavera_project_id = child.child[xn].projectSettings.projectid


# import pandas as pd
import os, csv
import json


class CostEPSExtractor:
    def __init__(self, file_location="", output_location=""):
        self.data = json.load(open(file_location, "r"))
        self.output_location = output_location
        self.filename = file_location[
            file_location.find("/") + 1 : file_location.find(".") + 1
        ]

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def collect_parent_ids(self, node, listofobj=None):
        if listofobj is None:
            listofobj = []  # Initialize an empty list for parentIds
        obj = {}
        obj["project"] = self.get_val(node, ["shortName"])
        obj["aconexId"] = self.get_val(node, ["aconexId"])
        obj["child_project_id"] = self.get_val(node, ["id"])
        obj["project_setting_id"] = self.get_val(node, ["projectSettings", "projectId"])

        if (
            obj["project"] == ""
            and obj["aconexId"] == ""
            and obj["project_setting_id"] == ""
        ):
            pass
        else:
            listofobj.append(obj)

        if "children" in node:
            for child in node["children"]:
                self.collect_parent_ids(child, listofobj)

        return listofobj

    def remove_duplicate_dicts(self, array_of_dicts):
        # Create a set to store a hash of each dictionary
        seen = set()

        # Create a new list to store the unique dictionaries
        unique_dicts = []

        for d in array_of_dicts:
            # Convert the dictionary to a frozenset of key-value pairs and hash it
            frozen_dict = frozenset(d.items())

            # If the hash is not in the set, it's a new unique dictionary
            if frozen_dict not in seen:
                seen.add(frozen_dict)
                unique_dicts.append(d)

        return unique_dicts

    def process_cost_eps(self):
        try:
            result = []

            for parent_child in self.get_val(self.data, ["body", "children"]):
                obj = {
                    "region": "",
                    "project": "",
                    "aconexId": "",
                    "child_project_id": "",
                    "project_setting_id": "",
                }
                # Region
                obj["region"] = parent_child["name"]
                res = self.collect_parent_ids(parent_child)
                for child in res:
                    obj1 = obj.copy()
                    obj1["project"] = child["project"]
                    obj1["aconexId"] = child["aconexId"]
                    obj1["child_project_id"] = child["child_project_id"]
                    obj1["project_setting_id"] = child["project_setting_id"]
                    result.append(obj1)

            # df = pd.DataFrame.from_dict(result)
            # df = df.drop_duplicates()
            # df.to_csv(
            #     os.path.join(self.output_location, self.filename + "csv"), index=False
            # )
            result = self.remove_duplicate_dicts(result)
            with open(
                os.path.join(self.output_location, self.filename + "csv"), "w"
            ) as f:
                w = csv.DictWriter(f, obj.keys())
                w.writeheader()
                for r in result:
                    w.writerow(r)
            return True
        except Exception as e:
            raise e


# p = CostEPSExtractor(file_location="COST_EPS.json", output_location=".")
# if p.process_cost_eps():
#     print("Processed")
