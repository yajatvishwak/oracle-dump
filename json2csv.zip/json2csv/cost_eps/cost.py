# cost eps.json

# Region - 1 child.name
# project - child.child[xn].shortname
# acconex - child.child[xn].acconexid
# child_project_id = child.child[xn].id
# primavera_project_id = child.child[xn].projectSettings.projectid


import pandas as pd
import os, csv
import json


class CostEPSExtractor:
    def __init__(self, file_location="", output_location=""):
        self.data = json.load(open(file_location, "r"))
        if os.path.isdir(output_location):
            filename = (
                file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
                + ".csv"
            )
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def collect_parent_ids(self, node, listofobj=None):
        if listofobj is None:
            listofobj = []  # Initialize an empty list for parentIds
        obj = {}
        obj["project"] = self.get_val(node, ["shortName"])
        obj["aconexId"] = self.get_val(node, ["aconexId"])
        obj["child_project_id"] = self.get_val(node, ["id"])
        obj["project_setting_id"] = self.get_val(node, ["projectSettings", "projectId"])

        if (
            obj["project"] == ""
            and obj["aconexId"] == ""
            and obj["project_setting_id"] == ""
        ):
            pass
        else:
            listofobj.append(obj)

        if "children" in node:
            for child in node["children"]:
                self.collect_parent_ids(child, listofobj)

        return listofobj

    def process_cost_eps(self):
        try:
            result = []

            for parent_child in self.get_val(self.data, ["body", "children"]):
                obj = {
                    "region": "",
                    "project": "",
                    "aconexId": "",
                    "child_project_id": "",
                    "project_setting_id": "",
                }
                # Region
                obj["region"] = parent_child["name"]
                res = self.collect_parent_ids(parent_child)
                for child in res:
                    obj1 = obj.copy()
                    obj1["project"] = child["project"]
                    obj1["aconexId"] = child["aconexId"]
                    obj1["child_project_id"] = child["child_project_id"]
                    obj1["project_setting_id"] = child["project_setting_id"]
                    result.append(obj1)

            df = pd.DataFrame.from_dict(result)
            df = df.drop_duplicates()
            df.to_csv(self.output_location, index=False)
            return True
        except Exception as e:
            raise e


# p = CostEPSExtractor(file_location="COST_EPS.json", output_location="")
# if p.process_cost_eps():
#     print("Processed")
