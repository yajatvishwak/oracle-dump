import json
import pandas as pd
from pprint import pprint
import os
import numpy as np

# captured at -> attachments[nx].captured at,attachment.captured at -> all captured at
# captured by -> attachments[nx].captured by.firstname + last, attachment.captured bycaptured by.firstname + last -> all captured at
# captured org -> attachments[nx].captured by.org.firstname + last, attachment.captured by.org.firstname + last -> all captured at


# custom id value family id - nx


class IssueExtractor:
    def __init__(
        self, custom_field_file_location="", issue_file_location="", output_location=""
    ):
        filename = (
            issue_file_location[
                issue_file_location.rfind("/") + 1 : issue_file_location.rfind(".")
            ]
            + ".csv"
        )
        if os.path.isdir(output_location):
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

        self.issues_data = json.load(open(issue_file_location, "r", encoding="utf-8"))
        self.custom_fields_data = json.load(open(custom_field_file_location, "r"))
        self.meta_output_location = os.path.join(output_location, f"meta_{filename}")

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def parse_custom_fields(self):
        result = {}
        for customfield in self.get_val(self.custom_fields_data, ["custom_fields"]):
            family_id = self.get_val(customfield, ["family_id"])
            if family_id:
                result[family_id] = self.get_val(customfield, ["label"])

        return result

    def create_meta(self):
        d = {}
        d["results_on_page"] = self.get_val(self.issues_data, ["results_on_page"])
        d["page_size"] = self.get_val(self.issues_data, ["page_size"])
        d["page_number"] = self.get_val(self.issues_data, ["page_number"])
        d["total_results"] = self.get_val(self.issues_data, ["total_results"])
        d["total_pages"] = self.get_val(self.issues_data, ["total_pages"])

        df = pd.DataFrame.from_dict([d])
        df.to_csv(self.meta_output_location, index=False)
        return True

    def process_issues(self):
        custom_fields = self.parse_custom_fields()
        # print(custom_fields)
        result = []
        for issue in self.get_val(self.issues_data, ["issues"]):
            obj = {
                "Region": "",
                "Project/ABC": "",
                "Issue Number": "",
                "Issue Type": "",
                "Implementer": "",
                "Partner Agreement / Contract": "",
                "Description": "",
                "Status": "",
                "Location": "",
                "Location Detail": "",
                "Captured On": "",
                "Captured By": "",
                "Captured Org.": "",
                "Assigned": "",
                "Assigned To Org": "",
                "Assigned On": "",
                "Due Date": "",
                "Closed / Last Modified On": "",
                "Closed By": "",
                "Has Photo": "",
                "Photo Added By User": "",
                "Photo Added On": "",
                "Type of Feedback": "",
                "Issue Categorisation": "",
                "Type of Monitoring / Verification": "",
                "Severity Level": "",
                "Recommendation / Follow Up Action": "",
                "Is risk mitigation follow-up required?": "",
                "Custom": "",
                "Project Id": "",
                "Project Short Name": "",
                "Area Id": "",
            }
            obj["Issue Number"] = self.get_val(issue, ["issue_number"])
            obj["Issue Type"] = self.get_val(issue, ["issue_type", "name"])
            obj["Description"] = self.get_val(issue, ["description"])
            obj["Status"] = self.get_val(issue, ["status"])
            obj["Location"] = self.get_val(issue, ["area", "name"])
            obj["Location Detail"] = self.get_val(issue, ["location_detail"])
            obj["Project Id"] = self.get_val(issue, ["project", "id"])
            obj["Area Id"] = self.get_val(issue, ["area", "id"])
            obj["Project Short Name"] = self.get_val(issue, ["project", "short_name"])
            obj["Assigned On"] = self.get_val(issue, ["assigned_at"])
            obj["Assigned"] = (
                self.get_val(issue, ["assigned_to", "user", "first_name"])
                + " "
                + self.get_val(issue, ["assigned_to", "user", "last_name"])
            )
            obj["Assigned To Org"] = self.get_val(
                issue, ["assigned_to", "organization", "name"]
            )
            obj["Due Date"] = self.get_val(issue, ["due_date"])
            obj["Closed By"] = self.get_val(issue, ["closed_by"])
            if obj["Status"] == "Closed":
                obj["Closed / Last Modified On"] = self.get_val(issue, ["closed_at"])
            else:
                obj["Closed / Last Modified On"] = self.get_val(
                    issue, ["meta_data", "updated_at"]
                )
            obj["Has Photo"] = (
                "Y"
                if self.get_val(issue, ["attachment", "type"]) == "image/jpeg"
                else "N"
            )
            obj["Photo Added By User"] = (
                self.get_val(issue, ["attachment", "captured_by", "first_name"])
                + " "
                + self.get_val(issue, ["attachment", "captured_by", "last_name"])
            )
            obj["Photo Added On"] = self.get_val(issue, ["attachment", "captured_at"])
            obj["Captured On"] = self.get_val(issue, ["meta_data", "created_at"])
            obj["Captured By"] = (
                self.get_val(issue, ["meta_data", "created_by", "first_name"])
                + " "
                + self.get_val(issue, ["meta_data", "created_by", "last_name"])
            )
            obj["Captured Org."] = self.get_val(
                issue, ["meta_data", "created_by", "organization", "name"]
            )
            # custom_obj = {}
            # for family_id, column_name in custom_fields.items():
            #     custom_obj[column_name] = ""
            # myKeys = list(custom_obj.keys())
            # myKeys.sort()
            # custom_obj_sorted = {i: custom_obj[i] for i in myKeys}
            # obj.update(custom_obj_sorted)
            for custom in self.get_val(issue, ["custom_fields"]):
                family_id = self.get_val(custom, ["family_id"])
                value = self.get_val(custom, ["value"])
                label = self.get_val(custom_fields, [family_id])
                obj1 = obj.copy()
                if label in obj1:
                    obj1[label] = value
                obj1["Custom"] = self.get_val(custom, ["value"])
                result.append(obj1)

        df = pd.DataFrame.from_dict(result)

        # df = df.drop_duplicates()
        if not df.empty:
            df = df.replace("", np.nan).groupby("Issue Number").first().reset_index()
        df.to_csv(os.path.join(self.output_location), index=False)


# i = IssueExtractor("custom_fields.json", "issue.json", "")
# pprint(i.process_issues())
