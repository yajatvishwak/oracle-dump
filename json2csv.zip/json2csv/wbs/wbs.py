import pandas as pd
import os
import json


# project_id for each row
# refere 2.4.1 for mapping of RE-W2-02_Functional-and-Technical-Reporting-Design_UNHCR Reports_v1.0_10102023 file


class WBSExtractor:
    def __init__(
        self,
        file_location="",
        output_location="",
    ):
        self.data = json.load(open(file_location, "r"))
        if os.path.isdir(output_location):
            filename = (
                file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
                + ".csv"
            )
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def traverse_children(
        self, node, current_level=0, target_level=2, selected_fields=None, result=None
    ):
        if result is None:
            result = []  # Initialize the result list

        # Check if the current level is equal to the target level
        if current_level == target_level:
            if selected_fields is None:
                selected_fields = (
                    []
                )  # If no fields are specified, select all available fields
            node_data = {field: node.get(field) for field in selected_fields}
            result.append(node_data)

        # Check if the node has children
        if "children" in node:
            # Increment the level and loop through the children list
            for child in node["children"]:
                # Call the function recursively for each child
                self.traverse_children(
                    child, current_level + 1, target_level, selected_fields, result
                )

        return result  # Return the collected data

    def process_wbs(self):
        result = []
        for parent_child in self.get_val(self.data, ["body", "children"]):
            obj = {
                "Partner Agreement / Contract": "",
                "Outcome": "",
                "project_id": "",
                "id": "",
                "Code": "",
                "Output": "",
                "Financial Plan": "",
                "Expenditure Location": "",
                "Amendments / Reallocations": "",
                "Amendments": "",
                "Reallocations": "",
                "Current Financial Plan": "",
                "Actuals YTD": "",
                "Remaining to Spend": "",
                "Approved Changes": "",
                "Approved Amount": "",
                "child_id": "",
            }
            for i in self.traverse_children(
                parent_child,
                current_level=1,
                target_level=2,
                selected_fields=["name", "code", "children"],
            ):
                obj["Partner Agreement / Contract"] = i["code"]
                for child in self.get_val(i, ["children"]):  # 3rd level
                    obj1 = obj.copy()
                    obj1["Outcome"] = self.get_val(child, ["name"])
                    obj1["project_id"] = self.get_val(child, ["projectId"])
                    obj1["id"] = self.get_val(child, ["id"])
                    if (
                        isinstance(self.get_val(child, ["children"]), list)
                        and len(self.get_val(child, ["children"])) <= 0
                    ):
                        obj1["project_id"] = self.get_val(child, ["projectId"])
                        obj1["Code"] = self.get_val(child, ["code"])
                        result.append(obj1)

                    for child2 in self.get_val(child, ["children"]):  # 4th level
                        obj2 = obj1.copy()

                        obj2["Output"] = self.get_val(child2, ["name"])
                        if self.get_val(child, ["name"]) == "Instalments":
                            obj2["project_id"] = self.get_val(child, ["projectId"])
                            obj2["Code"] = self.get_val(child, ["code"])
                        else:
                            obj2["project_id"] = self.get_val(child2, ["projectId"])
                            obj2["Code"] = self.get_val(child2, ["code"])
                        obj2["Financial Plan"] = self.get_val(
                            child2, ["contractDetails", "approvedAmount"]
                        )
                        if self.get_val(child2, ["code"]).rfind("/") != -1:
                            obj2["Expenditure Location"] = (
                                self.get_val(self.data, ["body", "code"])
                                + "-"
                                + self.get_val(child2, ["code"])[
                                    self.get_val(child2, ["code"]).rindex("/") + 1 :
                                ]
                            )
                        else:
                            obj2["Expenditure Location"] = (
                                self.get_val(self.data, ["body", "code"])
                                + "-"
                                + self.get_val(child2, ["code"])
                            )
                        obj2["Approved Changes"] = self.get_val(
                            child2, ["contractDetails", "approvedChanges"]
                        )
                        obj2["Approved Amount"] = self.get_val(
                            child2, ["contractDetails", "approvedAmount"]
                        )
                        obj2["Amendments"] = ""
                        obj2["Reallocations"] = ""
                        obj2["Amendments / Reallocations"] = self.get_val(
                            child2, ["contractDetails", "approvedChanges"]
                        )

                        obj2["Current Financial Plan"] = self.get_val(
                            child2, ["contractDetails", "currentAmount"]
                        )
                        obj2["Actuals YTD"] = self.get_val(
                            child2, ["contractDetails", "approvedContractActuals"]
                        )

                        obj2["Remaining to Spend"] = self.get_val(
                            child2, ["contractDetails", "remainingToSpend"]
                        )
                        obj2["child_id"] = self.get_val(child2, ["id"])
                        result.append(obj2)

        df = pd.DataFrame.from_dict(result)
        df.to_csv(self.output_location, index=False)
        return True


# w = WBSExtractor(
#     wbs_file_location="WBS_response.json",
#     contract_response_location="contracts_response.json",
#     accounts_response_location="Control_accounts_response.json",
#     output_location="",
# )
# w.process_wbs()
# print(w.parse_accounts_response())
# w.process_accounts_response()
# w.process_contracts_response()
