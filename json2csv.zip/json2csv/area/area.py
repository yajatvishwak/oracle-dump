# areas.json

import os
import json
import csv
import pandas as pd


class AreaExtractor:
    def __init__(self, file_location="", output_location=""):
        self.data = json.load(open(file_location, "r"))
        if os.path.isdir(output_location):
            filename = (
                file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
                + ".csv"
            )
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

    def get_val(self, dict, keys):
        try:
            if isinstance(dict, str):
                return ""
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def process_area(self):
        try:
            obj = {"id": "", "name": ""}

            areas = self.get_val(self.data, ["areas"])
            obj["id"] = self.get_val(areas[0], ["id"])
            obj["name"] = self.get_val(areas[0], ["name"])

            df = pd.DataFrame.from_dict([obj])
            df = df.drop_duplicates()
            df.to_csv(self.output_location, index=False)
            return True
        except Exception as e:
            raise e


# p = AreaExtractor(file_location="2.json", output_location="")
# if p.process_area():
#     print("Processed")
