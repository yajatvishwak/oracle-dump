import click, traceback, sys
from datetime import datetime
from field.field import FieldInspectionExtractor
from area.area import AreaExtractor
from cost_eps.cost import CostEPSExtractor
from wbs.wbs import WBSExtractor
from wbscontract.wbs_contract import WBSContractExtractor
from wbsaccounts.wbsaccounts import WBSAccountsExtractor
from payments.payments import PaymentExtractor
from contracts_change.contract_change import ContractChangeExtractor
from contract_change_items.contract_change_items import ContractChangeItemsExtractor
from control_elements.control_elements import CostElementsExtractor
from issues.issue import IssueExtractor
from projects.projectresponse import ProjectResponseExtractor
from payitems.payitems import PayItemsExtractor
from workflow.workflows import WorkflowExtractor
from workflowstatus.workflowstatus import WorkflowStatusExtractor
from documents.documents import DocumentsExtractor
from cost_user.costuser import CostUserExtractor
from cost_security_profile.costsecurityprofile import CostSecurityProfileExtractor
from cost_user_project.costuserproject import CostUserProjectExtractor
from inbox.mail import MailInboxExtractor
from workflowoverdue.workflowoverdue import WorkflowOverdueExtractor
from mail_list.mail_list import MailListExtractor
from issues_overdue.issue_overdue import IssueOverdueExtractor
from cost_user_list.costuser import CostUserListExtractor
from cost_exclude_projects.costexcludeprojects import CostExcludeProjectsExtractor


@click.group()
def cli():
    pass


def log_exception():
    now = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    print("-" * 5, now, "-" * 5, file=open("errors/log.txt", "a+"))
    print(" ".join(sys.argv), file=open("errors/log.txt", "a+"))
    print(traceback.format_exc(), file=open("errors/log.txt", "a+"))
    print("-" * 30, file=open("errors/log.txt", "a+"))


@click.command(name="field-inspections", help="convert fields inspection json to csv")
@click.option("--input", required=True, help="input location of the json file")
@click.option("--output", required=True, help="output location of the csv file")
@click.option("--create_meta", is_flag=True, help="save page details to csv")
def fields(input, output, create_meta):
    try:
        click.echo("Reading from: " + input)
        click.echo("Writing to: " + output)
        f = FieldInspectionExtractor(file_location=input, output_location=output)
        if f.process_checklists():
            click.echo("Complete")
        if create_meta and f.create_meta():
            click.echo("Page details saved")
    except Exception as e:
        log_exception()


@click.command(name="area", help="convert area json to csv")
@click.option("--input", required=True, help="input location of the json file")
@click.option("--output", required=True, help="output location of the csv file")
def areas(input, output):
    try:
        click.echo("Reading from: " + input)
        click.echo("Writing to: " + output)
        a = AreaExtractor(file_location=input, output_location=output)
        if a.process_area():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(name="cost-eps", help="convert cost eps json to csv")
@click.option("--input", required=True, help="input location of the json file")
@click.option("--output", required=True, help="output location of the csv file")
def costeps(input, output):
    try:
        click.echo("Reading from: " + input)
        click.echo("Writing to: " + output)
        a = CostEPSExtractor(file_location=input, output_location=output)
        if a.process_cost_eps():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(name="wbs", help="convert wbs response json to csv")
@click.option("--input", required=True, help="input location of the wbs json file")
@click.option("--output", required=True, help="output location of the csv file")
def wbs(input, output):
    try:
        click.echo("Reading from: " + input)
        click.echo("Writing to: " + output)
        a = WBSExtractor(file_location=input, output_location=output)
        if a.process_wbs():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(name="contracts", help="convert wbs contract response json to csv")
@click.option("--input", required=True, help="input location of the wbs json file")
@click.option("--output", required=True, help="output location of the csv file")
def wbscontract(input, output):
    try:
        click.echo("Reading from: " + input)
        click.echo("Writing to: " + output)
        a = WBSContractExtractor(file_location=input, output_location=output)
        if a.process_contracts_response():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(name="control-accounts", help="convert wbs account response json to csv")
@click.option("--input", required=True, help="input location of the wbs json file")
@click.option("--output", required=True, help="output location of the csv file")
def wbsaccount(input, output):
    try:
        click.echo("Reading from: " + input)
        click.echo("Writing to: " + output)
        a = WBSAccountsExtractor(file_location=input, output_location=output)
        if a.process_accounts_response():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(
    name="payment-applications", help="convert payments response json to csv"
)
@click.option("--input", required=True, help="input location of the wbs json file")
@click.option("--output", required=True, help="output location of the csv file")
def payments(input, output):
    try:
        click.echo("Reading from: " + input)
        click.echo("Writing to: " + output)
        a = PaymentExtractor(file_location=input, output_location=output)
        if a.process_payments():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(
    name="contracts-change-orders", help="convert contract change response json to csv"
)
@click.option(
    "--input", required=True, help="input location of the contract change json file"
)
@click.option("--output", required=True, help="output location of the csv file")
def contract_change(input, output):
    try:
        click.echo("Reading from: " + input)
        click.echo("Writing to: " + output)
        a = ContractChangeExtractor(file_location=input, output_location=output)
        if a.process_contract_change():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(
    name="contracts-change-items", help="convert contract change items json to csv"
)
@click.option(
    "--input",
    required=True,
    help="input location of the contract change items json file",
)
@click.option("--output", required=True, help="output location of the csv file")
def contract_change_items(input, output):
    try:
        click.echo("Reading from: " + input)
        click.echo("Writing to: " + output)
        a = ContractChangeItemsExtractor(file_location=input, output_location=output)
        if a.process_contract_change_items():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(
    name="control-elements", help="convert contract change response json to csv"
)
@click.option(
    "--input", required=True, help="input location of the contract change json file"
)
@click.option("--output", required=True, help="output location of the csv file")
def control_element(input, output):
    try:
        click.echo("Reading from: " + input)
        click.echo("Writing to: " + output)
        a = CostElementsExtractor(file_location=input, output_location=output)
        if a.process_control_elements():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(name="project", help="convert project response xml to csv")
@click.option(
    "--input", required=True, help="input location of project response xml file"
)
@click.option("--output", required=True, help="output location of the csv file")
def project(input, output):
    try:
        click.echo("Reading from: " + input)
        click.echo("Writing to: " + output)
        a = ProjectResponseExtractor(file_location=input, output_location=output)
        if a.process_project_response():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(name="payitems", help="convert payitem json to csv")
@click.option("--input", required=True, help="input location of payitem json file")
@click.option("--output", required=True, help="output location of the csv file")
def payitem(input, output):
    try:
        click.echo("Reading from: " + input)
        click.echo("Writing to: " + output)
        a = PayItemsExtractor(file_location=input, output_location=output)
        if a.process_pay_items():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(name="field-issues", help="convert field issues json to csv")
@click.option(
    "--custom_field_file_location",
    required=True,
    help="input location of the custom fields json file",
)
@click.option(
    "--issue_file_location", required=True, help="input location of the issue json file"
)
@click.option("--output", required=True, help="output location of the csv file")
@click.option("--create_meta", is_flag=True, help="save page details to csv")
def issue(issue_file_location, custom_field_file_location, output, create_meta):
    try:
        click.echo("Reading custom file from: " + custom_field_file_location)
        click.echo("Reading issue file from: " + issue_file_location)
        click.echo("Writing to: " + output)
        a = IssueExtractor(
            issue_file_location=issue_file_location,
            custom_field_file_location=custom_field_file_location,
            output_location=output,
        )
        if a.process_issues():
            click.echo("Complete")
        if create_meta and a.create_meta():
            click.echo("Page details saved")
    except Exception as e:
        log_exception()


@click.command(name="workflows", help="convert workflows xml to csv")
@click.option(
    "--input",
    required=True,
    help="input location of the workflows xml file",
)
@click.option("--output", required=True, help="output location of the csv file")
@click.option("--create_meta", is_flag=True, help="save page details to csv")
def workflow(input, output, create_meta):
    try:
        click.echo("Reading xml file from: " + input)
        click.echo("Writing to: " + output)
        a = WorkflowExtractor(
            file_location=input,
            output_location=output,
        )
        if a.process_workflows():
            click.echo("Complete")
        if create_meta and a.create_meta():
            click.echo("Page details exported")
    except Exception as e:
        log_exception()


@click.command(name="workflow-status", help="convert workflows status xml to csv")
@click.option(
    "--input",
    required=True,
    help="input location of the workflows status xml file",
)
@click.option("--output", required=True, help="output location of the csv file")
@click.option("--create_meta", is_flag=True, help="save page details to csv")
def workflowstatus(input, output, create_meta):
    try:
        click.echo("Reading xml file from: " + input)
        click.echo("Writing to: " + output)
        a = WorkflowStatusExtractor(
            file_location=input,
            output_location=output,
        )
        if a.process_workflows():
            click.echo("Complete")
        if create_meta and a.create_meta():
            click.echo("Page details exported")
    except Exception as e:
        log_exception()


@click.command(
    name="workflow-overdue", help="convert workflows status (overdue) xml to csv"
)
@click.option(
    "--input",
    required=True,
    help="input location of the workflows status xml file",
)
@click.option("--output", required=True, help="output location of the csv file")
@click.option("--create_meta", is_flag=True, help="save page details to csv")
def workflowoverdue(input, output, create_meta):
    try:
        click.echo("Reading xml file from: " + input)
        click.echo("Writing to: " + output)
        a = WorkflowOverdueExtractor(
            file_location=input,
            output_location=output,
        )
        if a.process_workflow_overdue():
            click.echo("Complete")
        if create_meta and a.create_meta():
            click.echo("Page details exported")
    except Exception as e:
        log_exception()


@click.command(name="documents", help="convert documents xml to csv")
@click.option(
    "--input",
    required=True,
    help="input location of the document xml file",
)
@click.option("--output", required=True, help="output location of the csv file")
@click.option("--create_meta", is_flag=True, help="save page details to csv")
def workflowdocs(input, output, create_meta):
    try:
        click.echo("Reading xml file from: " + input)
        click.echo("Writing to: " + output)
        a = DocumentsExtractor(
            file_location=input,
            output_location=output,
        )
        if a.process_documents():
            click.echo("Complete")
        if create_meta and a.create_meta():
            click.echo("Page details exported")
    except Exception as e:
        log_exception()


@click.command(name="cost-user", help="convert acconex cost user json to csv")
@click.option(
    "--input",
    required=True,
    help="input location of the acconex cost user json file",
)
@click.option("--output", required=True, help="output location of the csv file")
def costuser(input, output):
    try:
        click.echo("Reading xml file from: " + input)
        click.echo("Writing to: " + output)
        a = CostUserExtractor(
            file_location=input,
            output_location=output,
        )
        if a.process_cost_user():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(
    name="cost-security-profile",
    help="convert acconex cost security profile json to csv",
)
@click.option(
    "--input",
    required=True,
    help="input location of the acconex cost security profile json file",
)
@click.option("--output", required=True, help="output location of the csv file")
def costsecurity(input, output):
    try:
        click.echo("Reading xml file from: " + input)
        click.echo("Writing to: " + output)
        a = CostSecurityProfileExtractor(
            file_location=input,
            output_location=output,
        )
        if a.process_cost_security_profile():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(
    name="cost-user-project",
    help="convert acconex cost user project json to csv",
)
@click.option(
    "--input",
    required=True,
    help="input location of the acconex cost user project json file",
)
@click.option("--output", required=True, help="output location of the csv file")
def costuserproject(input, output):
    try:
        click.echo("Reading xml file from: " + input)
        click.echo("Writing to: " + output)
        a = CostUserProjectExtractor(
            file_location=input,
            output_location=output,
        )
        if a.process_cost_user_project():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(
    name="mail-inbox",
    help="convert mail inbox to csv",
)
@click.option(
    "--input",
    required=True,
    help="input location of the mail inbox file",
)
@click.option("--output", required=True, help="output location of the csv file")
@click.option("--create_meta", is_flag=True, help="save page details to csv")
def inbox(input, output, create_meta):
    try:
        click.echo("Reading xml file from: " + input)
        click.echo("Writing to: " + output)
        a = MailInboxExtractor(
            file_location=input,
            output_location=output,
        )
        if a.process_mailinbox():
            click.echo("Complete")
        if create_meta and a.create_meta():
            click.echo("Page details exported")
    except Exception as e:
        log_exception()


@click.command(
    name="mail-sentbox",
    help="convert mail sentbox to csv",
)
@click.option(
    "--input",
    required=True,
    help="input location of the mail sentbox file",
)
@click.option("--output", required=True, help="output location of the csv file")
@click.option("--create_meta", is_flag=True, help="save page details to csv")
def sentbox(input, output, create_meta):
    try:
        click.echo("Reading xml file from: " + input)
        click.echo("Writing to: " + output)
        a = MailInboxExtractor(
            file_location=input,
            output_location=output,
        )
        if a.process_mailinbox():
            click.echo("Complete")
        if create_meta and a.create_meta():
            click.echo("Page details exported")
    except Exception as e:
        log_exception()


@click.command(
    name="mail-list",
    help="convert mail list xml to csv",
)
@click.option(
    "--input",
    required=True,
    help="input location of the  mail list xml file",
)
@click.option("--output", required=True, help="output location of the csv file")
def maillist(input, output):
    try:
        click.echo("Reading xml file from: " + input)
        click.echo("Writing to: " + output)
        a = MailListExtractor(
            file_location=input,
            output_location=output,
        )
        if a.process_maillist():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(
    name="issues-overdue",
    help="convert issue overdue json to csv",
)
@click.option(
    "--custom_field_file_location",
    required=True,
    help="input location of the custom fields json file",
)
@click.option(
    "--input",
    required=True,
    help="input location of the issue overdue json file",
)
@click.option("--output", required=True, help="output location of the csv file")
@click.option("--create_meta", is_flag=True, help="save page details to csv")
def issueoverdue(input, output, custom_field_file_location, create_meta):
    try:
        click.echo("Reading xml file from: " + input)
        click.echo("Writing to: " + output)
        a = IssueOverdueExtractor(
            file_location=input,
            output_location=output,
            custom_field_file_location=custom_field_file_location,
        )
        if a.process_issue_overdue():
            click.echo("Complete")
        if create_meta and a.create_meta():
            click.echo("Page details exported")
    except Exception as e:
        log_exception()


@click.command(
    name="cost-user-list",
    help="convert cost user list json to csv",
)
@click.option(
    "--input",
    required=True,
    help="input location of the issue overdue json file",
)
@click.option("--output", required=True, help="output location of the csv file")
def costuserlist(
    input,
    output,
):
    try:
        click.echo("Reading xml file from: " + input)
        click.echo("Writing to: " + output)
        a = CostUserListExtractor(
            file_location=input,
            output_location=output,
        )
        if a.process_cost_user_list():
            click.echo("Complete")
    except Exception as e:
        log_exception()


@click.command(
    name="cost-exclude-projects",
    help="convert cost-exclude-projects json to csv",
)
@click.option(
    "--input",
    required=True,
    help="input location of the cost-exclude-projects json file",
)
@click.option("--output", required=True, help="output location of the csv file")
def costprojectexclude(
    input,
    output,
):
    try:
        click.echo("Reading xml file from: " + input)
        click.echo("Writing to: " + output)
        a = CostExcludeProjectsExtractor(
            file_location=input,
            output_location=output,
        )
        if a.process_cost_exclude():
            click.echo("Complete")
    except Exception as e:
        log_exception()


cli.add_command(fields)
cli.add_command(areas)
cli.add_command(costeps)
cli.add_command(wbs)
cli.add_command(wbscontract)
cli.add_command(wbsaccount)
cli.add_command(payments)
cli.add_command(contract_change)
cli.add_command(control_element)
cli.add_command(issue)
cli.add_command(project)
cli.add_command(payitem)
cli.add_command(contract_change_items)
cli.add_command(workflow)
cli.add_command(workflowdocs)
cli.add_command(workflowstatus)
cli.add_command(costuser)
cli.add_command(costsecurity)
cli.add_command(costuserproject)
cli.add_command(inbox)
cli.add_command(sentbox)
cli.add_command(workflowoverdue)
cli.add_command(maillist)
cli.add_command(issueoverdue)
cli.add_command(costuserlist)
cli.add_command(costprojectexclude)

if __name__ == "__main__":
    cli()
