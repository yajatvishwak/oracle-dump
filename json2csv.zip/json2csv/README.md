# json2csv for UNHCR

Run:

`python cli.py --help`

Install

`pip install -r requirements.txt`
