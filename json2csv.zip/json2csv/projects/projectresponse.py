# xml file - project

# project_id
# project_short_name


from utils.gomma import parse
import pandas as pd
import os


class ProjectResponseExtractor:
    def __init__(self, file_location="", output_location=""):
        self.data = parse(open(file_location, "r").read())
        if os.path.isdir(output_location):
            filename = (
                file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
                + ".csv"
            )
            self.output_location = os.path.join(output_location, filename)
        else:
            self.output_location = output_location

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def process_project_response(self):
        try:
            result = []
            for project in self.get_val(
                self.data, ["ProjectResults", "SearchResults", "Project"]
            ):
                obj = {"Project Short Name": "", "Project Id": ""}
                obj["Project Short Name"] = self.get_val(project, ["ProjectShortName"])
                obj["Project Id"] = self.get_val(project, ["ProjectId"])
                result.append(obj)
            df = pd.DataFrame.from_dict(result)
            df = df.drop_duplicates()
            df.to_csv(self.output_location, index=False)
            return True
        except Exception as e:
            raise e


# p = ProjectResponseExtractor(
#     file_location="input/ProjectResponse.xml", output_location="output"
# )
# if p.process_project_response():
#     print("Processed")
