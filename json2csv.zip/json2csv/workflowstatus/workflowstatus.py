# xml file - project

# project_id
# project_short_name


from utils.gomma import parse
import pandas as pd
import os
from dateutil.parser import parse as date_parser
from math import fsum


class WorkflowStatusExtractor:
    def __init__(
        self,
        output_location,
        file_location="",
    ) -> None:
        self.data = parse(open(file_location, "r").read())
        filename_without_csv = file_location[
            file_location.rfind("/") + 1 : file_location.rfind(".")
        ]
        filename = (
            file_location[file_location.rfind("/") + 1 : file_location.rfind(".")]
            + ".csv"
        )
        if os.path.isdir(output_location):
            self.output_location = os.path.join(output_location, filename)
            self.output_location_docs = os.path.join(
                output_location, filename_without_csv + "_workflow_overdue.csv"
            )
        else:
            self.output_location = output_location
        self.meta_output_location = os.path.join(output_location, f"meta_{filename}")

    def get_val(self, dict, keys):
        try:
            for key in keys:
                dict = dict[key]
            return dict
        except:
            return ""

    def get_target(self, target_workflow_number, output_column):
        result = []
        for workflow in self.get_val(
            self.data, ["WorkflowSearch", "SearchResults", "Workflow"]
        ):
            if workflow["WorkflowNumber"] == target_workflow_number:
                result.append(self.get_val(workflow, [output_column]))
        return result

    def convert_to_datetime(self, data):
        result = []
        if isinstance(data, list):
            for date in data:
                if date:
                    result.append(date_parser(date))
        return result

    def convert_to_floats(self, data):
        result = []
        if isinstance(data, list):
            for number in data:
                result.append(float(number))
        return result

    def create_meta(self):
        d = {}
        d["TotalResultsOnPage"] = self.get_val(
            self.data, ["WorkflowSearch", "@TotalResultsOnPage"]
        )
        d["TotalResults"] = self.get_val(self.data, ["WorkflowSearch", "@TotalResults"])
        d["TotalPages"] = self.get_val(self.data, ["WorkflowSearch", "@TotalPages"])
        d["PageSize"] = self.get_val(self.data, ["WorkflowSearch", "@PageSize"])
        d["CurrentPage"] = self.get_val(self.data, ["WorkflowSearch", "@CurrentPage"])

        df = pd.DataFrame.from_dict([d])
        df.to_csv(self.meta_output_location, index=False)
        return True

    def process_workflows(self):
        try:
            result = []
            for workflow in self.get_val(
                self.data, ["WorkflowSearch", "SearchResults", "Workflow"]
            ):
                # type, review status
                obj = {
                    "Region": "",
                    "Project/ABC": "",
                    "Partner Agreement / Contract": "",
                    "Implementer": "",
                    "Template": "",
                    "Number": "",
                    "Workflow Status": "",
                    "Start Date": "",
                    "Expected/Actual End Date": "",
                    "Original Due Date": "",
                    "Expected Duration": "",
                    "Delay (days)": "",
                    "Date Completed": "",
                    "Date Due": "",
                    "Step Status": "",
                    "Document Tracking ID": "",
                }

                obj["Template"] = self.get_val(workflow, ["WorkflowTemplate"])
                obj["Date Completed"] = self.get_val(workflow, ["DateCompleted"])
                obj["Date Due"] = self.get_val(workflow, ["DateDue"])
                obj["Workflow Status"] = self.get_val(workflow, ["WorkflowStatus"])
                obj["Number"] = self.get_val(workflow, ["WorkflowNumber"])

                obj["Expected Duration"] = self.get_val(workflow, ["Duration"])
                obj["Start Date"] = self.get_val(workflow, ["DateIn"])
                obj["Original Due Date"] = self.get_val(workflow, ["OriginalDueDate"])
                obj["Step Status"] = self.get_val(workflow, ["StepStatus"])
                obj["Document Tracking ID"] = self.get_val(
                    workflow, ["DocumentTrackingId"]
                )

                # durations = self.convert_to_floats(
                #     self.get_target(
                #         target_workflow_number=obj["Number"], output_column="Duration"
                #     )
                # )
                # obj["Expected Duration"] = fsum(durations)

                # min_dates = self.convert_to_datetime(
                #     self.get_target(
                #         target_workflow_number=obj["Number"], output_column="DateIn"
                #     )
                # )
                # if len(min_dates) > 0:
                #     obj["Start Date"] = min(min_dates).strftime("%Y-%m-%d")

                # max_due_date = self.convert_to_datetime(
                #     self.get_target(
                #         target_workflow_number=obj["Number"],
                #         output_column="OriginalDueDate",
                #     )
                # )
                # if len(max_due_date) > 0:
                #     obj["Original Due Date"] = min(max_due_date).strftime("%Y-%m-%d")

                result.append(obj)
            # print(self.data)

            df = pd.DataFrame.from_dict(result)
            df = df.drop_duplicates()
            df.to_csv(self.output_location, index=False)
            return True
        except Exception as e:
            raise e
