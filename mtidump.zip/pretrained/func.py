import io
import json

from fdk import response

import logging, traceback
from datetime import datetime
from ai import AI
import requests

logging.basicConfig(
    format="[%(filename)s:%(lineno)d] %(message)s",
    filename="log.log",
    encoding="utf-8",
    level=logging.DEBUG,
    filemode="w",
)


def papa_log(item_to_log, err=False):
    if err:
        logging.debug(traceback.format_exc())
    else:
        logging.debug(item_to_log)


now = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
papa_log(now)


def parse_pretrained(input_bucket_name, input_file_name):
    try:
        ai = AI()
        kv = ai.KVDetector(
            input_bucket_name=input_bucket_name, input_file_name=input_file_name
        )
        logging.getLogger().info(kv)
        return kv
    except Exception as e:
        logging.getLogger().info(e)

def keep_highest_confidence(data):
    filtered_data = {}
    entries_without_key = []
    for entry in data:
        if 'key' not in entry:
            entries_without_key.append(entry)
            continue
        key = entry['key']
        confidence = entry['confidence']

        if key not in filtered_data or confidence > filtered_data[key]['confidence']:
            filtered_data[key] = entry

    filtered_result = list(filtered_data.values()) + entries_without_key
    return filtered_result

def api_request(url):
    try:
        response = requests.post(url)
        return response.text
    except Exception as e:
        papa_log(e, err=True)


def handler(ctx, data: io.BytesIO = None):
    try:
        body = json.loads(data.getvalue())
        bucket_name = body.get("bucket")
        filename = body.get("filename")
        batch_id = body.get("batch_id")
        res = parse_pretrained(bucket_name, filename)
        res = keep_highest_confidence(res)
        logging.getLogger().info("This is the response")
        logging.getLogger().info(res)
        api_request(f"https://ebdke1uahmuvcab-aipocadwdb.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/invoices/updatepercentage/{batch_id}/33")
    except (Exception, ValueError) as ex:
        logging.getLogger().info('error parsing json payload: ' + str(ex))

    logging.getLogger().info("Inside Python Hello World function")
    return response.Response(
        ctx, response_data=json.dumps(
             res, default=str),
        headers={"Content-Type": "application/json"}
    )
