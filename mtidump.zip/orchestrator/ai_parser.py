import json, re
from pprint import pprint
from datetime import datetime
from dateutil import parser


class AIParser:
    def convert_date_format(self, input_date_string, output_format='%m/%d/%y'):
        try:
            input_date = parser.parse(input_date_string)
            output_date_string = input_date.strftime(output_format)
            return output_date_string
        except Exception as e:
            return input_date_string

    def convert_number_to_float(self, input_value):
        if isinstance(input_value, (int, float)):
            return [float(input_value)]
        elif isinstance(input_value, str):
            # Update the regular expression to handle commas in the number
            numbers = re.findall(r"[-+]?\d+(?:,\d{3})*(?:\.\d+)?|\.\d+", input_value)
            float_numbers = [float(num.replace(',', '')) for num in numbers]
            if len(float_numbers) == 0:
                return [0.0]
            return float_numbers

        return [0.0]

    def convert_currency(self, fin_kv):
        if fin_kv["InvoiceCurrency"]["value"] not in ["INR", "USD", "EUR", "GBP"]:
            fin_kv["InvoiceCurrency"]["value"] = ""
            fin_kv["InvoiceCurrency"]["confidence"] = 0.0
        return fin_kv
    
    def ensure_number(self, fin_kv):
        number_columns=["InvoiceAmount", "CGST", "SGST", "IGST", "TotalTax", "Cess"]
        for col in number_columns:
            fin_kv[col]["value"] = self.convert_number_to_float(fin_kv[col]["value"])[0]
        return fin_kv
    
    def ensure_date(self, fin_kv):
        date_columns=["InvoiceDate"]
        for col in date_columns:
            fin_kv[col]["value"] = self.convert_date_format(fin_kv[col]["value"])
        return fin_kv

    def run(self, kv):
        res_kv = []
        for i in kv:
            if(i != None):
                res_kv.append(self.extract(i))

        pprint(res_kv)
        res = self.merge_dicts(res_kv)
        final_with_cleaned_currency = self.convert_currency(res)
        final_with_parsed_numbers = self.ensure_number(final_with_cleaned_currency)
        final_with_parsed_dates = self.ensure_date(final_with_parsed_numbers)
        
        return final_with_parsed_dates

    def merge_dicts(self, dicts):
        output = dicts[0].copy()

        for d in dicts[1:]:
            for key, value in output.items():
                if key == "LineItems":
                    continue

                if isinstance(value, dict):
                    current_confidence = float(value.get("confidence", 0))
                    new_confidence = d.get(key, {}).get("confidence", 0)
                    if new_confidence > current_confidence:
                        output[key] = d.get(key, value)

        return output

    def extract(
        self,
        kv,
    ):
        data = json.load(open("mapper.json", "r"))

        output = {key: {"confidence": 0, "value": ""} for key in data.keys()}

        for key in output.keys():
            output[key]["value"] = self.extract_value(kv, key)
            output[key]["confidence"] = self.extract_value(
                kv, key, return_confidence=True
            )

        # extract line items separately
        output["LineItems"] = []
        for item in kv:
            if "type" in item and item["type"] == "LINE_ITEM_GROUP":
                processed_line_items = self.extract_line_items(item["value"])
                output["LineItems"].append(processed_line_items)

        # pprint(output)
        return output

    def extract_value(self, data, key, return_confidence=False):
        value = ""
        mapper = json.load(open("mapper.json", "r"))
        for obj in data:
            for k in mapper[key]:
                if "key" in obj and obj["key"] == k:
                    if return_confidence:
                        value = obj["confidence"]
                    else:
                        value = obj["value"]

        if return_confidence and value == "":
            return 0
        return value

    def extract_line_items(
        self,
        data,
    ):
        mapper_line = json.load(open("line-items.json"))
        fin = {key: {"confidence": 0, "value": ""} for key in mapper_line.keys()}
        for obj in data:
            for key in fin.keys():
                for k in mapper_line[key]:
                    if obj["key"] == k:
                        fin[key]["value"] = obj["value"]
                        fin[key]["confidence"] = obj["confidence"]
        return fin
