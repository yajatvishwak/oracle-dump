import io
import json
import logging

from fdk import response

from datetime import datetime
import requests
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
import time, oci
from oci import functions
from pprint import pprint

from ai_parser import AIParser

def api_request(url,content):
    try:
        response = requests.post(url, json=content)
        return response.text
    except Exception as e:
        # update log table here - saying unable to call ords to update payload in db
        pass

def api_request_with_auth(url,content, auth):
    try:
        response = requests.post(url, json=content , auth=auth)
        return response.text
    except Exception as e:
        # update log table here - saying unable to call ords to update payload in db
        pass
def invoke_function(function_ocid, content):
    try:
        config = oci.config.from_file("config", "DEFAULT")
        invoke_client = functions.FunctionsInvokeClient(
            config,
            service_endpoint="https://hsyp6faoxya.us-ashburn-1.functions.oci.oraclecloud.com",
        )

        resp = invoke_client.invoke_function(
            function_id=function_ocid,
            invoke_function_body=json.dumps(content, default=str),
        )
        return resp.data.text
    except:
        # update log table here - failed to call the function
        return ""

def call_multiple_apis(requests):
    try:
        results = []

        with ThreadPoolExecutor() as executor:
            # Submit API requests asynchronously
            futures = {
                executor.submit(invoke_function, req["url"], req["body"]): req
                for req in requests
            }

            # Wait for all futures to complete
            for future in as_completed(futures):
                req = futures[future]
                try:
                    result = future.result()
                    # Store the result along with the original request data
                    fin = {"request": req["url"], "result": json.loads(result)}
                    results.append(fin)
                except Exception as e:
                    # update log table here - failed to call the function
                    pass

        return results
    except:
        return []


def processs_file(filename, bucket, batch_id):
    parser = AIParser()
    pre_url = "ocid1.fnfunc.oc1.iad.aaaaaaaadd5kii5isr7r5ryssbpdm3zkwcj5uvr3fqthlbhp4mgyoifwhz2q"
    cus_url = "ocid1.fnfunc.oc1.iad.aaaaaaaajtsesfie2oxtqdz5pqsqn7bm5hcv27zqgzsq7j6ec63xtqj2z5fq"
    cus_gst_url = "ocid1.fnfunc.oc1.iad.aaaaaaaav7ciscvp3z5y35tkzm77ab4s2cs22g2pqvkg2lycg22bfqb4g3ca"

    req = [
        {
            "url": pre_url,
            "body": {"bucket": bucket, "filename": filename ,  "batch_id": batch_id,},
        },
        {
            "url": cus_url,
            "body": {"bucket": bucket, "filename": filename, "batch_id": batch_id,},
        },
        {
            "url": cus_gst_url,
            "body": {"bucket": bucket, "filename": filename, "batch_id": batch_id,},
        },
    ]

    res = call_multiple_apis(req)
    kv = []
    # # we need to pass the first kv as the pretrained result only to the parser
    # # this code will make sure that the first object in the array is the pretrained object
    for item in res:
        if item["request"] == pre_url:
            kv.insert(0, item["result"])
        else:
            kv.append(item["result"])
    fin = parser.run(kv)
    return fin


def call_multiple_files(filenames, bucket, batch_id):
    results = []

    with ThreadPoolExecutor() as executor:
        futures = {
            executor.submit(processs_file, filename, bucket, batch_id): filename
            for filename in filenames
        }
        for future in as_completed(futures):
            file = futures[future]
            try:
                start = time.time()
                result = future.result()
                fin = {"filename": file, "kv": result}
                results.append(fin)
                end = time.time()
                delay = end-start
                x = api_request(f"https://ebdke1uahmuvcab-aipocadwdb.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/invoices/updatepayload/{batch_id}/{file}/{delay}",result)
                x = json.loads(x)
                logging.getLogger().info("json x: ")
                logging.getLogger().info(x)
                if "return_status" in x and x["return_status"] == "PO INVOICE":
                    bid = x["return_batch_id"]
                    iid = x["return_invoice_id"]
                    logging.getLogger().info("response from x : " + str(bid) +"a"+ str(iid))
                    cred = ("sushovit.das@oracle.com","Sush1999#Oracle@MTI")
                    
                    b = api_request_with_auth("https://oic-mti-dev-idb4yrxmkhc7-ia.integration.ocp.oraclecloud.com:443/ic/api/integration/v1/flows/rest/MTI_UPLOAD_PO_INVOICE/1.0/oic/api/Invoice/BatchId", {"batchId" : bid, "invoiceId" :iid}, cred)
                    logging.getLogger().info("response from api : " + b)
                
            except Exception as e:
                    # update log table here - failed for file
                    pass

    return results


def orchestrate(filenames, bucket, batch_id):
    try:
        result = call_multiple_files(filenames, bucket, batch_id)
        return result
    except:
        return []






def handler(ctx, data: io.BytesIO = None):
    r = []
    try:
        start = time.time()
        body = json.loads(data.getvalue())
        filenames = body.get("filenames")
        
        bucket = body.get("bucket")
        batch_id = body.get("batch_id")
        
        unzipped_files = invoke_function("ocid1.fnfunc.oc1.iad.aaaaaaaaljit3vyhgk7n3pi77ze4svsigcgbg25qxxwddrz5ptysb7lytiuq", {
            "filename" :  filenames,
            "input_bucket_name": bucket,
            "batch_id":batch_id
        })
        unzipped_files = json.loads(unzipped_files)["result"]
        filenames = unzipped_files
        
        r = orchestrate(filenames, bucket,batch_id)
        #api_request(f"https://ebdke1uahmuvcab-aipocadwdb.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/invoices/updatepayload/{batch_id}",r)
        end = time.time()
    
    except (Exception, ValueError) as ex:
        return response.Response(
            ctx, response_data=json.dumps(
                {"error" : str(ex),"batch_id": batch_id},default=str),
            headers={"Content-Type": "application/json"}
        )


    if r == []:
        return response.Response(
            ctx, response_data=json.dumps(
                {"error" : "No response from AI service, check log tables for more details" , "batch_id": batch_id},default=str),
            headers={"Content-Type": "application/json"}
        )
    else:
        return response.Response(
                ctx, response_data=json.dumps(
                    {"result" : r, "time_taken_in_secs" : end-start},default=str),
                headers={"Content-Type": "application/json"}
            )

        
