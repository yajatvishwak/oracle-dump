import io, os, oci, zipfile
import json
import logging, string, random
from fdk import response
from oci import functions
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

from pathlib import Path

def api_request(url):
    try:
        response = requests.post(url)
        return response.text
    except Exception:
        return ""

def upload_to_oci(bucket_name, file_location):
    filename = os.path.basename(file_location)
    #requests.put(f"https://idb4yrxmkhc7.objectstorage.us-ashburn-1.oci.customer-oci.com/p/jLpIse3PsNHsUjFvqJRk_xHqUld8EOULehaGjNSpSBFBJnSwlo0UpYFd-DuKtRPP/n/idb4yrxmkhc7/b/MTI_new/o/{filename}")
    config = oci.config.from_file("config", "DEFAULT")
    bucket_service = oci.object_storage.ObjectStorageClient(config)
    uploader = oci.object_storage.UploadManager(bucket_service)
    uploader.upload_file(bucket_name=bucket_name, namespace_name="idb4yrxmkhc7", file_path=file_location,object_name=filename, content_type="application/pdf")
    print(f"Uploaded {filename}")


def download_from_oci(bucket_name, filename, save_location="/tmp/"):
    config = oci.config.from_file("config", "DEFAULT")
    bucket_service = oci.object_storage.ObjectStorageClient(config)
    get_object_response = bucket_service.get_object(
                                    namespace_name="idb4yrxmkhc7",
                                    bucket_name=bucket_name,
                                    object_name=filename)
    with open(os.path.join(save_location,filename),'wb') as f:
       for chunk in get_object_response.data.raw.stream(1024 * 1024, decode_content=False):
           f.write(chunk)
    print(f"Downloaded {filename}")

def invoke_function(function_ocid, content):
    try:
        config = oci.config.from_file("config", "DEFAULT")
        invoke_client = functions.FunctionsInvokeClient(
            config,
            service_endpoint="https://hsyp6faoxya.us-ashburn-1.functions.oci.oraclecloud.com",
        )

        resp = invoke_client.invoke_function(
            function_id=function_ocid,
            invoke_function_body=json.dumps(content, default=str),
        )
        return resp.data.text
    except:
        # update log table here - failed to call the function
        return ""


def call_multiple_apis(requests):
    try:
        results = []
        with ThreadPoolExecutor() as executor:
            # Submit API requests asynchronously
            futures = {
                executor.submit(invoke_function, req["url"], req["body"]): req
                for req in requests
            }

            # Wait for all futures to complete
            for future in as_completed(futures):
                req = futures[future]
                try:
                    result = future.result()
                    # Store the result along with the original request data
                    fin = {"request": req["url"], "result": json.loads(result)}
                    results.append(fin)
                except Exception as e:
                    # update log table here - failed to call the function
                    pass

        return results
    except:
        return []


def unzip_and_correct(input_bucket_name ="", output_bucket_name="", zipfile_name = "", batch_id=""):
    try:
        download_from_oci(input_bucket_name, zipfile_name)
        zipfile_name_without_ext = zipfile_name.split(".")[0]
        extracted_filenames = []

        with zipfile.ZipFile(os.path.join("/tmp", zipfile_name), mode="r") as archive:
            Path(os.path.join("/tmp", zipfile_name_without_ext)).mkdir(
                parents=True, exist_ok=True
            )
            archive.extractall(os.path.join("/tmp", zipfile_name_without_ext))

        for filename in os.listdir(os.path.join("/tmp", zipfile_name_without_ext)):
            f = os.path.join("/tmp", zipfile_name_without_ext, filename)
            if os.path.isfile(f):
                upload_to_oci(input_bucket_name, file_location=f)
                extracted_filenames.append(filename)

        # reqs = []
        # for filename in extracted_filenames:
        #     reqs.append(
        #         {
        #             "url": "ocid1.fnfunc.oc1.iad.aaaaaaaaadh2a4l3jgao7c5743pvvpgqr6myopkon5y6kr2xzemkofjxffbq",
        #             "body": {
        #                 "input_filename": filename,
        #                 "input_bucket": input_bucket_name,
        #                 "output_bucket_name": output_bucket_name,
        #             },
        #         }
        #     )
        # result = call_multiple_apis(reqs)
        api_request(f"https://ebdke1uahmuvcab-aipocadwdb.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/invoices/updateinvoicecount/{batch_id}/{len(extracted_filenames)}")
        return extracted_filenames
    except:
        return []

def just_correct(input_bucket_name ="", output_bucket_name="", filename = "",batch_id=""):
    try: 
        # reqs = [{
        #             "url": "ocid1.fnfunc.oc1.iad.aaaaaaaaadh2a4l3jgao7c5743pvvpgqr6myopkon5y6kr2xzemkofjxffbq",
        #             "body": {
        #                 "input_filename": filename,
        #                 "input_bucket": input_bucket_name,
        #                 "output_bucket_name": output_bucket_name,
        #             },
        #         }]
        # result = call_multiple_apis(reqs)
        api_request(f"https://ebdke1uahmuvcab-aipocadwdb.adb.us-ashburn-1.oraclecloudapps.com/ords/admin/invoices/updateinvoicecount/{batch_id}/1")
        return [filename]
    except:
        return -1
   
def get_file_extension(filename):
    path = Path(filename)
    return path.suffix


def handler(ctx, data: io.BytesIO = None):
    try:
        result = None
        body = json.loads(data.getvalue())
        batch_id = body.get("batch_id")
        filename = body.get("filename")
        input_bucket_name = body.get("input_bucket_name")
        output_bucket_name = body.get("output_bucket_name")



        if output_bucket_name == None or output_bucket_name == "":
            output_bucket_name = input_bucket_name

        if get_file_extension(filename) == ".zip":
            result = unzip_and_correct(input_bucket_name=input_bucket_name, output_bucket_name=output_bucket_name, zipfile_name=filename, batch_id=batch_id)
        elif get_file_extension(filename) == ".pdf":
            result = just_correct(input_bucket_name=input_bucket_name, output_bucket_name=output_bucket_name, filename=filename,batch_id=batch_id)
        else:
            response.Response(
                ctx, response_data=json.dumps(
                    {"output": "errored", "message": "Only zip/pdf file supported"}),
                headers={"Content-Type": "application/json"}
            )
            
            
        
        
        
        if result and len(result) == 0:
            response.Response(
                ctx, response_data=json.dumps(
                    {"output": "errored", "message": "No files in zip file"}),
                headers={"Content-Type": "application/json"}
            )
        else:
            result = {"result" : result}
    except (Exception, ValueError) as ex:
        return response.Response(
            ctx, response_data=json.dumps(
                {"output": "errored", "message": str(ex)}),
            headers={"Content-Type": "application/json"}
        )
            

    
    return response.Response(
        ctx, response_data=json.dumps(
            result),
        headers={"Content-Type": "application/json"}
    )
