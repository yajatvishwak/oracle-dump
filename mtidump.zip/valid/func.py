import io
import json
import logging, string, random

import requests
from fdk import response
from pytesseract import Output
import pytesseract
import img2pdf
import imutils
import cv2, os
from pdf2image import convert_from_path
import shutil, time
import pathlib, oci

from pathlib import Path

def upload_to_oci(bucket_name, file_location, filename_to_save=""):
    #requests.put(f"https://idb4yrxmkhc7.objectstorage.us-ashburn-1.oci.customer-oci.com/p/jLpIse3PsNHsUjFvqJRk_xHqUld8EOULehaGjNSpSBFBJnSwlo0UpYFd-DuKtRPP/n/idb4yrxmkhc7/b/MTI_new/o/{}")
    config = oci.config.from_file("config", "DEFAULT")
    bucket_service = oci.object_storage.ObjectStorageClient(config)
    uploader = oci.object_storage.UploadManager(bucket_service)
    uploader.upload_file(bucket_name=bucket_name, namespace_name="idb4yrxmkhc7", file_path=file_location,object_name=filename_to_save,content_type="application/pdf")
    print(f"Uploaded {file_location} as {filename_to_save}")


def download_from_oci(bucket_name, filename, save_location="/tmp/"):
    config = oci.config.from_file("config", "DEFAULT")
    bucket_service = oci.object_storage.ObjectStorageClient(config)
    get_object_response = bucket_service.get_object(
                                    namespace_name="idb4yrxmkhc7",
                                    bucket_name=bucket_name,
                                    object_name=filename)
    with open(os.path.join(save_location,filename),'wb') as f:
       for chunk in get_object_response.data.raw.stream(1024 * 1024, decode_content=False):
           f.write(chunk)
    print(f"Downloaded {filename}")


def images_to_pdf(input_folder, output_pdf):
    image_files = [
        f
        for f in os.listdir(input_folder)
        if f.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".bmp"))
    ]

    if not image_files:
        print("No image files found in the specified directory.")
        return
    image_files.sort()
    images = []
    for image_file in image_files:
        image_path = os.path.join(input_folder, image_file)
        images.append(image_path)
    with open(output_pdf, "wb") as pdf_file:
        pdf_file.write(img2pdf.convert(images))

    print(f"PDF created successfully: {output_pdf}")


def empty_folder(folder_path):
    try:
        # Remove all files in the folder
        for file_name in os.listdir(folder_path):
            file_path = os.path.join(folder_path, file_name)
            if os.path.isfile(file_path):
                os.remove(file_path)

        # Remove all subdirectories in the folder
        for dir_name in os.listdir(folder_path):
            dir_path = os.path.join(folder_path, dir_name)
            if os.path.isdir(dir_path):
                shutil.rmtree(dir_path)

        print(f"Folder emptied successfully: {folder_path}")

    except Exception as e:
        print(f"Error: {e}")

def generate_random_filename(length: int = 24, extension: str = "") -> str:
    characters = string.ascii_letters + string.digits
    random_string = "".join(random.choice(characters) for _ in range(length))
    if extension:
        if "." in extension:
            pieces = extension.split(".")
            last_extension = pieces[-1]
            extension = last_extension
        return f"{random_string}.{extension}"
    return random_string


def correct_pdf(bucket_name,filename,output_bucket_name):
    empty_folder("/tmp/")
    download_from_oci(bucket_name = bucket_name,filename=filename)
    pathlib.Path('/tmp/corrected').mkdir(parents=True, exist_ok=True) 
    pathlib.Path('/tmp/pdf').mkdir(parents=True, exist_ok=True) 
    empty_folder("/tmp/corrected")
    empty_folder("/tmp/pdf")
    
    images = convert_from_path(f"/tmp/{filename}")
    
    for i in range(len(images)):
        images[i].save(f"/tmp/pdf/page{i}.jpg", "JPEG")
        image = cv2.imread(f"/tmp/pdf/page{i}.jpg")
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = pytesseract.image_to_osd(rgb, output_type=Output.DICT)
        # display the orientation information
        print("[INFO] detected orientation: {}".format(results["orientation"]))
        print("[INFO] rotate by {} degrees to correct".format(results["rotate"]))
        print("[INFO] detected script: {}".format(results["script"]))

        rotated = imutils.rotate_bound(image, angle=results["rotate"])
        cv2.imwrite(f"/tmp/corrected/page{i}.jpg", rotated)

    print("brooo pls")
    print(os.listdir("/tmp/"))
    print(os.listdir("/tmp/pdf"))
    print(os.listdir("/tmp/corrected"))

    output_pdf_path=f"/tmp/{Path(filename).stem}_corrected.pdf"
    with open(output_pdf_path, "w"):
        images_to_pdf(
            input_folder="/tmp/corrected",
            output_pdf=output_pdf_path,
        )
        upload_to_oci(bucket_name,output_pdf_path,filename)
        #empty_folder("/tmp/corrected")
        #empty_folder("/tmp/pdf")
        
        return  {
            "output_bucket_name" : output_bucket_name,
            "filename" : filename,
        }


def handler(ctx, data: io.BytesIO = None):
    try:
        body = json.loads(data.getvalue())
        input_filename = body.get("input_filename")
        bucket_name = body.get("input_bucket")
        output = correct_pdf(filename=input_filename, bucket_name=bucket_name, output_bucket_name=bucket_name)
    except (Exception, ValueError) as ex:
        logging.getLogger().error(ex)
        return response.Response(
        ctx, response_data=json.dumps(
            {"output": "error", "message" : str(ex), "files": os.listdir("/tmp")}),
        headers={"Content-Type": "application/json"}
    )

    
    return response.Response(
        ctx, response_data=json.dumps(
            {"files": os.listdir("/tmp/corrected"), "pdf" :os.listdir("/tmp/corrected"), }),
        headers={"Content-Type": "application/json"}
    )
