import oci
from client import CONFIG_PATH
import json, random, string, time
from pprint import pprint


from oci.signer import Signer
import requests


class AI:
    def __init__(self) -> None:
        pass

    def get_random_string(self):
        return "".join(
            random.choice(string.ascii_uppercase + string.digits) for _ in range(7)
        )

    def createLanguageClient(self):
        config = oci.config.from_file(CONFIG_PATH, "DEFAULT")
        return oci.ai_document.AIServiceDocumentClient(config)

    def KVDetector(
        self,
        modelID=None,
        input_bucket_name="oradocscanner",
        input_file_name="",
        output_bucket_name="oradocscanner",
        document_type="INVOICE",
        prefix="bruKVDetector",
    ):
        AI_client = self.createLanguageClient()
        try:
            document_entities = AI_client.analyze_document(
                analyze_document_details=oci.ai_document.models.AnalyzeDocumentDetails(
                    features=[
                        oci.ai_document.models.DocumentKeyValueExtractionFeature(
                            feature_type="KEY_VALUE_EXTRACTION",
                            model_id=modelID,
                        )
                    ],
                    document=oci.ai_document.models.ObjectStorageDocumentDetails(
                        source="OBJECT_STORAGE",
                        namespace_name="idb4yrxmkhc7",
                        bucket_name=input_bucket_name,
                        object_name=input_file_name,
                    ),
                    output_location=oci.ai_document.models.OutputLocation(
                        namespace_name="idb4yrxmkhc7",
                        bucket_name=output_bucket_name,
                        prefix=prefix,
                    ),
                    document_type=document_type,
                )
            )
            # print(document_entities.data.pages)
            output = []  # [{type:"", key: "", value: ""}]
            data = list(document_entities.data.pages)
            for page in data:
                for documentField in page.document_fields:
                    if documentField.field_type == "KEY_VALUE":
                        output.append(
                            {
                                "key": documentField.field_label.name,
                                "type": documentField.field_type,
                                "value": documentField.field_value.value,
                                "confidence": documentField.field_label.confidence,
                            }
                        )
                    if documentField.field_type == "LINE_ITEM_GROUP":
                        items = json.loads(str(documentField.field_value.items))
                        # print(items)
                        for item in items:
                            r = []
                            for lineitem in item["field_value"]["items"]:
                                r.append(
                                    {
                                        "key": lineitem["field_label"]["name"],
                                        "type": lineitem["field_type"],
                                        "value": lineitem["field_value"]["value"],
                                        "confidence": lineitem["field_label"][
                                            "confidence"
                                        ],
                                    }
                                )
                            output.append({"type": "LINE_ITEM_GROUP", "value": r})
            return output
        except Exception as e:
            raise e
        return None

    def TableDetector(
        self,
        input_bucket_name="oradocscanner",
        input_file_name="",
        output_bucket_name="oradocscanner",
        prefix="bruKVDetector",
    ):
        AI_client = self.createLanguageClient()
        try:
            document_entities = AI_client.analyze_document(
                analyze_document_details=oci.ai_document.models.AnalyzeDocumentDetails(
                    features=[
                        oci.ai_document.models.DocumentTableExtractionFeature(
                            feature_type="TABLE_EXTRACTION"
                        ),
                    ],
                    document=oci.ai_document.models.ObjectStorageDocumentDetails(
                        source="OBJECT_STORAGE",
                        namespace_name="idb4yrxmkhc7",
                        bucket_name=input_bucket_name,
                        object_name=input_file_name,
                    ),
                    output_location=oci.ai_document.models.OutputLocation(
                        namespace_name="idb4yrxmkhc7",
                        bucket_name=output_bucket_name,
                        prefix=prefix,
                    ),
                )
            )
            fin = []
            pages = document_entities.data.pages
            for page in pages:
                # print(type(page))
                tables = page.tables
                for table in tables:
                    optable = [
                        ["" for _ in range(table.column_count)]
                        for _ in range(table.row_count)
                    ]
                    headerRows = []
                    bodyRows = []
                    for cells in table.header_rows:
                        for cell in cells.cells:
                            optable[cell.row_index][cell.column_index] = cell.text
                            headerRows.append(cell.text)
                    for body in table.body_rows:
                        rows = body.cells
                        row = []
                        for items in rows:
                            optable[items.row_index][items.column_index] = items.text
                            row.append(items.text)
                        bodyRows.append(row)

                    headerRows = optable[0]
                    bodyRows = optable[1:]
                    fin.append({"body": bodyRows, "header": headerRows})
            return fin
        except Exception as e:
            raise e

    # Experimental
    def BarcodeDetector(
        self,
        input_bucket_name="oradocscanner",
        input_file_name="",
        output_bucket_name="oradocscanner",
    ):
        config = oci.config.from_file(CONFIG_PATH, "DEFAULT")
        auth = Signer(
            tenancy=config["tenancy"],
            user=config["user"],
            fingerprint=config["fingerprint"],
            private_key_file_location=config["key_file"],
            pass_phrase=config["pass_phrase"],
        )

        # CHANGE COMPARMENTID AND BUCKET NAMES
        compartment_id = "ocid1.compartment.oc1..aaaaaaaaretksgipt3jgwfpzgh4ijyw54uynyfviaxs5li4wtl744fj4fi3q"
        namespace_name = "idb4yrxmkhc7"

        object_location = oci.ai_document.models.ObjectLocation()
        object_location.namespace_name = namespace_name
        object_location.bucket_name = input_bucket_name
        object_name = [input_file_name]
        object_location.object_name = object_name[0]

        output_location = oci.ai_document.models.OutputLocation()
        output_location.namespace_name = namespace_name
        output_location.bucket_name = output_bucket_name
        output_location.prefix = self.get_random_string()

        url = "https://document.aiservice.us-ashburn-1.oci.oraclecloud.com/20221109/processorJobs"

        payload = json.dumps(
            {
                "processorConfig": {
                    "processorType": "GENERAL",
                    "features": [{"featureType": "DOCUMENT_ELEMENTS_EXTRACTION"}],
                    "isZipOutputEnabled": False,
                },
                "inputLocation": {
                    "sourceType": "OBJECT_STORAGE_LOCATIONS",
                    "objectLocations": [
                        {
                            "bucketName": object_location.bucket_name,
                            "namespaceName": object_location.namespace_name,
                            "objectName": object_location.object_name,
                        }
                    ],
                },
                "outputLocation": {
                    "bucketName": output_location.bucket_name,
                    "namespaceName": output_location.namespace_name,
                    "prefix": output_location.prefix,
                },
                "compartmentId": compartment_id,
            }
        )
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        response = requests.request(
            "POST", url, headers=headers, data=payload, auth=auth
        )
        response_dict = json.loads(response.text)
        processor_id = response_dict["id"]

        object_storage_client = oci.object_storage.ObjectStorageClient(config=config)
        get_object_response = object_storage_client.get_object(
            namespace_name=output_location.namespace_name,
            bucket_name=output_location.bucket_name,
            object_name="{}/{}/{}_{}/results/{}.json".format(
                output_location.prefix,
                processor_id,
                object_location.namespace_name,
                object_location.bucket_name,
                object_location.object_name,
            ),
        )
        data = json.loads(str(get_object_response.data.content.decode("utf-8")))

        result = []
        for page in data["pages"]:
            for barcode in page["barCodes"]:
                result.append(
                    {"value": barcode["value"], "confidence": barcode["confidence"]}
                )

        return result


class AIParser:
    def __init__(self) -> None:
        self.ai = AI()

    def run(self, filename="mti.pdf"):
        pretrainedkv = self.ai.KVDetector(
            input_file_name=filename,
            input_bucket_name="berger",
        )
        customkv = self.ai.KVDetector(
            input_file_name=filename,
            input_bucket_name="berger",
            modelID="ocid1.aidocumentmodel.oc1.iad.amaaaaaazv3jruqau4o7fxghcgrymdcr7c2qnmceagwtykxig66hdrxvi5bq",
        )
        barcode = self.ai.BarcodeDetector(
            input_file_name=filename,
        )
        # # run extraction on both
        res_pre_kv = self.extract(pretrainedkv)
        res_custom_kv = self.extract(customkv)
        res = self.merge_dicts(res_pre_kv, res_custom_kv)
        res["meta"] = {
            "barcode": barcode,
        }

        pprint(res)

    def merge_dicts(self, dict1, dict2):
        output = dict1.copy()
        for key, value in output.items():
            if key in ["LineItems"]:
                continue
            if value["confidence"] == "" and value["value"] == "":
                output[key] = dict2[key]
        return output

    def extract(
        self,
        kv,
    ):
        data = json.load(open("mapper.json", "r"))
        output = {key: {} for key in data.keys()}
        for key in output.keys():
            output[key]["value"] = self.extract_value(kv, key)
            output[key]["confidence"] = self.extract_value(
                kv, key, return_confidence=True
            )

        # extract line items separately
        output["LineItems"] = []
        for item in kv:
            if "type" in item and item["type"] == "LINE_ITEM_GROUP":
                processed_line_items = self.extract_line_items(item["value"])
                output["LineItems"].append(processed_line_items)

        # pprint(output)
        return output

    def extract_value(self, data, key, return_confidence=False):
        value = ""
        mapper = json.load(open("mapper.json", "r"))
        for obj in data:
            for k in mapper[key]:
                if "key" in obj and obj["key"] == k:
                    if return_confidence:
                        value = obj["confidence"]
                    else:
                        value = obj["value"]

        return value

    def extract_line_items(
        self,
        data,
    ):
        mapper_line = json.load(open("line-items.json"))
        fin = {key: {"confidence": "", "value": ""} for key in mapper_line.keys()}
        for obj in data:
            for key in fin.keys():
                for k in mapper_line[key]:
                    if obj["key"] == k:
                        fin[key]["value"] = obj["value"]
                        fin[key]["confidence"] = obj["confidence"]
        return fin
