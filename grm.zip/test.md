__FIXED PRICE EXHIBIT __

__Your Name: Test Customer 1, Inc\.		__

__Ordering Document Number:	__

__Exhibit Number:__

1. Description of Services and Deliverables\.
2. Services\.  

Test Provider 1 will assist You with the following consulting services within the framework of the “SolutionCloud” project implementation for 2 \(two\) entities of the next Test Provider 1 Cloud Solution:

- 
	1. Enterprise Resource Planning \(“ERP”\) Cloud Service\.
	2. Supply Chain Management \(“SCM”\) Cloud Service\.
	3. Customer Experience \(“CX”\)\.
	4. Data Upload\.

The term "SolutionCloud" refers to your project, known as the "Test Provider 1 Cloud Project," related to implementing Test Provider 1 Cloud Services in the countries where you have a presence\.

1. __ERP \(Enterprise Resource Planning\) Cloud Services __

To assist in providing the standard functionality embedded in the following Test Provider 1 Cloud modules to support Your corresponding processes in the implementation of Your SolutionCloud Project:

1. __Test Provider 1 ERP \(Enterprise Resource Planning\) Cloud – Accounts Receivables__

Processes in scope – Accounts Receivables:

1. Manage customers\.
2. Billing process\.
3. Receipt process\.
4. Customer statement generation\.
5. Accounting and period close\.
6. Lockbox for processing receipts\.
7. Auto Invoice process from external systems\.
8. __SCM \(Supply Chain Management\) Cloud Services__

To provide the standard functionality embedded in the following Test Provider 1 Cloud modules to support Your corresponding processes in the implementation of Your SolutionCloud Project:

1. Order Management\.
2. Product Hub\. 
3. Inventory Management and Cost Management\.
4. Manufacturing\.
5. Warehouse Management\.
6. OTM
7. __CX Cloud Services__

To provide the standard functionality embedded in the following Test Provider 1 Cloud modules to support the corresponding processes:

1. Customer Data Management \(CDM\)
2. Engagement Cloud
3. __Standard functionality Test Provider 1 Customer Data Management__

Processes in scope – CDM

1. Profiling and Initial Load of Customers\.
2. Cleaning Processes – Setup of Processes to Avoid Duplications and Standardize Addresses\.
3. Validation – Validation of current information according to new requirements\.
4. Data Governance – Set up matching rules to detect and suggest changes to duplicate records\.  
5. Setup of Approval Workflow to accept new customers\.
6. Quality Key Performance Indicators \(KPI\) to control the data quality\.
7. Advanced Publish and Webservices – Setup of procedures to publish the customer data in a schema of “Publish and Subscribe\.” 
8. __Standard functionality Test Provider 1 Engagement Cloud__

	Processes in scope – Engagement Cloud

1. Test Provider 1 Engagement Cloud Foundation \- The Foundation provides the functionality to define and configure Contact, Account, and Activity Management and the basis for implementing additional modules following enterprise setup and configuration tasks\.
2. Setup to support order creation from external sources using web services\.
3. Setup of Workflow Approval for Orders and returns\.
4. Sales Catalog \- Sales Catalog enables companies to group products and promotions into multi\-tiered product groups with child product items\.
5. Test Provider 1 Transactional Business Intelligence \- Test Provider 1 Engagement Cloud’s built\-in reporting capabilities use Test Provider 1 Transaction Business Intelligence \(“OTBI”\) for real\-time reporting against the transactional database\.
6. Application Extensibility Framework \- The various extensibility tools incorporated into Test Provider 1 Engagement Cloud, such as Application Composer and Page Composer, allow for custom fields and entities to be created and transactional screen layouts to be altered\.

	Processes out of scope – Engagement Cloud

1. Lead Management
2. Opportunity Management
3. Service
4. Territory Management
5. __Data Upload__
6. __Activities in scope ERP/SCM/CX__
7. Adjust data mapping for the entities/objects in scope\. 
8. Adjust migration data components\. 
9. Data migration to the ERP/SCM/CX Cloud development environment for the User Acceptance Testing \(“UAT”\)\.  
10. Data migration to the ERP/SCM/CX Cloud production environment\.
11. __Objects in scope:__

The following list of entities/objects are considered for Data Migration ERP/SCM/CX on Cloud:

			

__\#__

__Group__

__Entities/ Objects__

1

AR – Open invoices / Unapplied Receipts

Open Balances

2

AR – Customers 

Active Customers

3

INV – On hand 

On hand Availability

4

CDM – Customers

Active Customers

1. Testing strategy

Test Provider 1 will assist in executing the following tests up to 2 \(two\) weeks of the extract and reporting in the context of the process to which they belong\.

	__End\-to\-end Tests \(“E2E”\)\.__

This test aims to corroborate that the behavior of each module adapts to the requirements for which it was defined:

After the unit tests, end\-to\-end testing activities will executed to validate the functionality across modules, processes, and external applications\.

\. 

The estimated time for the End\-to\-end test \(“E2E”\) is 2 \(two\) weeks\.

__User Acceptance Tests \(“UAT”\)\.__

You must approve the system once the previous tests have been carried out\. For this, you will carry out the test of the operations and processes that you perform daily to detect problems or deviations:

- 
	- 
		- 
			1. In the final validation stage, you will test the functionality to validate the complete working conditions to ensure the operation won’t be disrupted\. 
			2. The users must test the complete Test Scenarios\.
			3. The NA Test1 Project team will lead the activity
			4. Test Provider 1 Consulting will assist Your key users assigned to this activity\.
			5. The estimated time for the User Acceptance Test \(“UAT”\) is 2 \(two\) weeks\.

1. Post\-Production Assistance 

__Preparation for production__

- 
	1. Test Provider 1 will accompany you while enabling the listed integrations in the production environment\.

__Post\-Production Assistance__

Once the application enters production and starts, Test Provider 1 will accompany you for ten \(10\) days, equivalent to 240 \(two hundred forty\) hours of actual operation; support will be remote\.

- The support defined as Hypercare will be executed remotely\.
- Does not include new changes/requirements\.
- Once the Hypercare period is complete, all remaining open issues will be transferred to Your Ongoing Support area following the procedures defined\.

1. Deliverables\.

__No\.__

__Deliverable Name__

__Deliverable Description__

1

Project Management Plan

The Project Management Plan establishes the project's governance model, including the detailed plans used to manage the project\.

2

GAPs List \(MoSCoW\) 

"Production of a prioritized list of requirements by the business \(both functional and supplemental\)\. MoSCoW provides a method for focusing on the relative importance of requirements\. The acronym MoSCoW stands for:

__Must\-Have__: critical requirements without which the system cannot function

__Should Have__: requirements that are important but not critical to the system\.

__Could Have__: requirements that are desirable but which could be left out of the increment under development\.

__Won't Have__: requirements that are valuable but will not be delivered by the increment under development\."

3

 Local Functional Design Validation \(Future State Design\)

Validation of the global model with the particularities of the country or company in which the implementation will be made\.

4

Application Setup Ready for Validation – End to End \(“E2E”\)

Configuration information for the functionality that is in scope for the project for E2E\. This document has iterations during the project execution\.

5

Application Setup Ready for Validation – User Acceptance Test \(“UAT”\)

Configuration information for the functionality that is in scope for the project for UAT\. This document has iterations during the project execution\.

6

End\-to\-End Review \- User Acceptance Test \(“UAT”\)

Documentation of UAT tests with screenshots evidence\. 

7

Readiness Assessment Document

Checklists to confirm that you have the sign to the Go Live \(Production\)\.

8

Post\-Go\-Live Support

As specified in the contract, monitor and respond to problems and issues throughout the post\-production support period\.

9

Final Acceptance Document

The Final Acceptance Certificate verifies that the contracted project scope was delivered\.

# Fees, Expenses, and Taxes\.  

1. You agree to pay Test Provider 1 the fee specified below for the Services and deliverables\.  This fee does not include expenses or taxes\.  Once a deliverable is accepted, or deemed accepted, by Section 2 \(Acceptance of Deliverables\) above, the corresponding fee for such deliverable specified below becomes due and payable, and Test Provider 1 shall, after that invoice, You shall pay such fee; this payment obligation shall become non\-cancelable, and the sum paid non\-refundable on such acceptance date, except as may otherwise be provided in the Master Agreement\.

	

__Deliverable No\.__

__Deliverable Name__

__Deliverable Fee__

1

Project Management Plan

$10,000\.00

2

Local Functional Design Validation \(Future State Design\)

$10,000\.00

3

Post\-Go\-Live Support

$10,000\.00

4

Final Acceptance Document

$10,000\.00

__Total Fixed Fee__

__$40,000\.00__

Any expenses will be invoiced monthly\.  

1. Project Assumptions\.
2. Duration: The estimated duration of this service is 9 \(nine\) months from the effective date\.
3. The parties acknowledge and agree that the provision of services does not require or imply processing personal data\. 
4. Services will be provided remotely\.
5. A Steering Committee composed of Your management team, the Test Provider 1 team, and project managers from both parties will be established to review project progress, resolve strategic issues, and approve any deviations from the project's focus, scope, methodology, cost, and timeline\.
6. A project sponsor will be designated to oversee services and participate in the Steering Committee\. Test Provider 1 can appoint a representative to participate in Steering Committee meetings\. 
7. The term "solution" refers to an approach to the customer's project and does not intend to force Test Provider 1 to "solve" any problems\. 
8. Test Provider 1 Cloud services come with standard functionality that will be used as provided\.
9. The scope of this project will be for two new Legal Entities\.

