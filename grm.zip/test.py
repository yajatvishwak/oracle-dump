import re

from pprint import pprint


def extract_headers(markdown_content):
    headers = []
    lines = markdown_content.split("\n")

    for line in lines:
        if line.startswith("#"):
            header_level = 0
            while header_level < len(line) and line[header_level] == "#":
                header_level += 1

            header_text = line[header_level:].strip()
            headers.append((header_level, header_text))

    return headers


def extract_paragraphs(markdown_content):
    paragraphs = []
    lines = markdown_content.split("\n")
    current_paragraph = ""

    for line in lines:
        if not line.startswith("#"):
            current_paragraph += line + "\n"
        elif current_paragraph:
            paragraphs.append(current_paragraph.strip())
            current_paragraph = ""

    # Save the last paragraph if there is any
    if current_paragraph:
        paragraphs.append(current_paragraph.strip())

    return paragraphs


def extract_tables(markdown_content):
    tables = re.findall(r"\n\|(.*\|.*)*\n((?:\|.*\|)\n)+", markdown_content)
    return tables


def organize_content(headers, paragraphs):
    content_dict = {}
    current_header = None

    for level, text in headers:
        current_header = (level, text)
        content_dict[current_header] = []

    if current_header:
        content_dict[current_header] = paragraphs

    return content_dict


def read_markdown_file(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        return file.read()


def main():
    markdown_file_path = "new.md"
    markdown_content = read_markdown_file(markdown_file_path)

    headers = extract_headers(markdown_content)
    paragraphs = extract_paragraphs(markdown_content)
    tables = extract_tables(markdown_content)

    content_dict = organize_content(headers, paragraphs)

    pprint(content_dict)


if __name__ == "__main__":
    main()
