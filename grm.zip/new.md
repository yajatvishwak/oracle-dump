### FIXED PRICE EXHIBIT

```
Your Name: Test Customer 1, Inc.
Ordering Document Number:
Exhibit Number:
```
# H1. Description of Services and Deliverables.

## 1.1. Services.

```
Test Provider 1 will assist You with the following consulting services within the framework of the “SolutionCloud”
project implementation for 2 (two) entities of the next Test Provider 1 Cloud Solution:
```
1. Enterprise Resource Planning (“ERP”) Cloud Service.
2. Supply Chain Management (“SCM”) Cloud Service.
3. Customer Experience (“CX”).
4. Data Upload.

```
The term "SolutionCloud" refers to your project, known as the "Test Provider 1 Cloud Project," related to
implementing Test Provider 1 Cloud Services in the countries where you have a presence.
```
# 1.1.1 ERP (Enterprise Resource Planning) Cloud Services

```
To assist in providing the standard functionality embedded in the following Test Provider 1 Cloud modules to
support Your corresponding processes in the implementation of Your SolutionCloud Project:
```
```
a. Test Provider 1 ERP (Enterprise Resource Planning) Cloud – Accounts Receivables
```
```
Processes in scope – Accounts Receivables:
```
```
a. Manage customers.
b. Billing process.
c. Receipt process.
d. Customer statement generation.
e. Accounting and period close.
f. Lockbox for processing receipts.
g. Auto Invoice process from external systems.
```
# 1.1.2 SCM (Supply Chain Management) Cloud Services

```
To provide the standard functionality embedded in the following Test Provider 1 Cloud modules to support Your
corresponding processes in the implementation of Your SolutionCloud Project:
```
```
a. Order Management.
b. Product Hub.
c. Inventory Management and Cost Management.
d. Manufacturing.
e. Warehouse Management.
f. OTM
```
# 1.1.3 CX Cloud Services

```
To provide the standard functionality embedded in the following Test Provider 1 Cloud modules to support the
corresponding processes:
```
```
a. Customer Data Management (CDM)
b. Engagement Cloud
```

```
a. Standard functionality Test Provider 1 Customer Data Management
```
```
Processes in scope – CDM
a. Profiling and Initial Load of Customers.
b. Cleaning Processes – Setup of Processes to Avoid Duplications and Standardize
Addresses.
c. Validation – Validation of current information according to new requirements.
d. Data Governance – Set up matching rules to detect and suggest changes to duplicate
records.
e. Setup of Approval Workflow to accept new customers.
f. Quality Key Performance Indicators (KPI) to control the data quality.
g. Advanced Publish and Webservices – Setup of procedures to publish the customer data in
a schema of “Publish and Subscribe.”
```
```
b. Standard functionality Test Provider 1 Engagement Cloud
```
Processes in scope – Engagement Cloud
a. Test Provider 1 Engagement Cloud Foundation - The Foundation provides the functionality
to define and configure Contact, Account, and Activity Management and the basis for
implementing additional modules following enterprise setup and configuration tasks.
b. Setup to support order creation from external sources using web services.
c. Setup of Workflow Approval for Orders and returns.
d. Sales Catalog - Sales Catalog enables companies to group products and promotions into
multi-tiered product groups with child product items.
e. Test Provider 1 Transactional Business Intelligence - Test Provider 1 Engagement Cloud’s
built-in reporting capabilities use Test Provider 1 Transaction Business Intelligence
(“OTBI”) for real-time reporting against the transactional database.
f. Application Extensibility Framework - The various extensibility tools incorporated into Test
Provider 1 Engagement Cloud, such as Application Composer and Page Composer, allow
for custom fields and entities to be created and transactional screen layouts to be altered.

```
Processes out of scope – Engagement Cloud
```
1. Lead Management
2. Opportunity Management
3. Service
4. Territory Management

## 1.2 Data Upload

## a. Activities in scope ERP/SCM/CX

1. Adjust data mapping for the entities/objects in scope.
2. Adjust migration data components.
3. Data migration to the ERP/SCM/CX Cloud development environment for the User Acceptance
    Testing (“UAT”).
4. Data migration to the ERP/SCM/CX Cloud production environment.

## b. Objects in scope:

```
The following list of entities/objects are considered for Data Migration ERP/SCM/CX on Cloud:
```
```
# Group Entities/ Objects
1 AR – Open invoices / Unapplied Receipts Open Balances
2 AR – Customers Active Customers
```

```
# Group Entities/ Objects
3 INV – On hand On hand Availability
4 CDM – Customers Active Customers
```
# H2. Testing strategy

```
Test Provider 1 will assist in executing the following tests up to 2 (two) weeks of the extract and reporting in the context
of the process to which they belong.
```
End-to- **end Tests (“E2E”).**
This test aims to corroborate that the behavior of each module adapts to the requirements for which it was defined:

```
After the unit tests, end-to-end testing activities will executed to validate the functionality across modules,
processes, and external applications.
.
The estimated time for the End-to-end test (“E2E”) is 2 (two) weeks.
```
```
User Acceptance Tests (“UAT”).
```
```
You must approve the system once the previous tests have been carried out. For this, you will carry out the test of
the operations and processes that you perform daily to detect problems or deviations:
```
## 1. In the final validation stage, you will test the functionality to validate the complete working

```
conditions to ensure the operation won’t be disrupted.
```
## 2. The users must test the complete Test Scenarios.

## 3. The NA Test1 Project team will lead the activity

## 4. Test Provider 1 Consulting will assist Your key users assigned to this activity.

## 5. The estimated time for the User Acceptance Test (“UAT”) is 2 (two) weeks.

# H3. Post-Production Assistance

```
Preparation for production
```
# Test Provider 1 will accompany you while enabling the listed integrations in the production environment.

## 3.1 Post-Production Assistance

```
Once the application enters production and starts, Test Provider 1 will accompany you for ten (10) days, equivalent
to 240 (two hundred forty) hours of actual operation; support will be remote.
```
- The support defined as Hypercare will be executed remotely.
- Does not include new changes/requirements.
- Once the Hypercare period is complete, all remaining open issues will be transferred to Your Ongoing
    Support area following the procedures defined.

# 3.1.1 Deliverables.


```
No. Deliverable Name Deliverable Description
1
Project Management
Plan
```
```
The Project Management Plan establishes the project's governance model,
including the detailed plans used to manage the project.
```
```
2 GAPs List (MoSCoW)
```
```
"Production of a prioritized list of requirements by the business (both
functional and supplemental). MoSCoW provides a method for focusing on
the relative importance of requirements. The acronym MoSCoW stands for:
Must-Have: critical requirements without which the system cannot function
Should Have: requirements that are important but not critical to the system.
Could Have: requirements that are desirable but which could be left out of
the increment under development.
Won't Have: requirements that are valuable but will not be delivered by the
increment under development."
```
```
3
```
```
Local Functional
Design Validation
(Future State Design)
```
```
Validation of the global model with the particularities of the country or
company in which the implementation will be made.
```
### 4

```
Application Setup
Ready for Validation –
End to End (“E2E”)
```
```
Configuration information for the functionality that is in scope for the project
for E2E. This document has iterations during the project execution.
```
### 5

```
Application Setup
Ready for Validation –
User Acceptance Test
(“UAT”)
```
```
Configuration information for the functionality that is in scope for the project
for UAT. This document has iterations during the project execution.
```
### 6

```
End-to-End Review -
User Acceptance Test
(“UAT”)
```
```
Documentation of UAT tests with screenshots evidence.
```
### 7

```
Readiness Assessment
Document Checklists to confirm that you have the sign to the Go Live (Production).^
8 Post-Go-Live Support
As specified in the contract, monitor and respond to problems and issues
throughout the post-production support period.
9
Final Acceptance
Document
```
```
The Final Acceptance Certificate verifies that the contracted project scope
was delivered.
```
# H4. Fees, Expenses, and Taxes.

```
A. You agree to pay Test Provider 1 the fee specified below for the Services and deliverables. This fee does not
include expenses or taxes. Once a deliverable is accepted, or deemed accepted, by Section 2 (Acceptance of
Deliverables) above, the corresponding fee for such deliverable specified below becomes due and payable, and
Test Provider 1 shall, after that invoice, You shall pay such fee; this payment obligation shall become non-
cancelable, and the sum paid non-refundable on such acceptance date, except as may otherwise be provided in
the Master Agreement.
```
```
Deliverable
No.
Deliverable Name
Deliverable
Fee
1 Project Management Plan $ 1 0,000.
2 Local Functional Design Validation (Future State Design) $10,000.^
3 Post-Go-Live Support $10,000.^
4 Final Acceptance Document $10,000.^
Total Fixed Fee $ 4 0,000.
```
```
Any expenses will be invoiced monthly.
```

# H5. Project Assumptions.

```
A. Duration: The estimated duration of this service is 9 (nine) months from the effective date.
A. The parties acknowledge and agree that the provision of services does not require or imply processing personal
data.
B. Services will be provided remotely.
C. A Steering Committee composed of Your management team, the Test Provider 1 team, and project managers from
both parties will be established to review project progress, resolve strategic issues, and approve any deviations
from the project's focus, scope, methodology, cost, and timeline.
D. A project sponsor will be designated to oversee services and participate in the Steering Committee. Test Provider
1 can appoint a representative to participate in Steering Committee meetings.
E. The term "solution" refers to an approach to the customer's project and does not intend to force Test Provider 1 to
"solve" any problems.
F. Test Provider 1 Cloud services come with standard functionality that will be used as provided.
G. The scope of this project will be for two new Legal Entities.
```


