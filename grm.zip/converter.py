from langchain.output_parsers import CommaSeparatedListOutputParser
from langchain.prompts import PromptTemplate
from langchain.llms.cohere import Cohere
from langchain.output_parsers.list import ListOutputParser

cohere_key = "ZSyCsFbScvmLh2lKLnqoVL6VlRmilnLsrDPP7txj"
llm = Cohere(cohere_api_key=cohere_key, temperature=0)


def convert_topic(response):
    output_parser = CommaSeparatedListOutputParser()

    format_instructions = output_parser.get_format_instructions()

    p = PromptTemplate(
        template="Extract all the topics in separate elements of a valid python list. \n {response}.\n{format_instructions}",
        input_variables=["response"],
        partial_variables={"format_instructions": format_instructions},
    )
    o = llm.invoke(p.format(response=response))
    r = output_parser.parse(o)
    r = list(set(r))
    return r
