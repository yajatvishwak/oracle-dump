from llmsherpa.readers import LayoutPDFReader
from pprint import pprint
import time

import cohere
import numpy as np

cohere_key = "ZSyCsFbScvmLh2lKLnqoVL6VlRmilnLsrDPP7txj"
co = cohere.Client(cohere_key)


class AI:
    def __init__(self, location) -> None:
        self.location = location
        self.doc_emb = None
        self.contexts = None
        pass

    def load_doc(self):
        start = time.time()
        llmsherpa_api_url = "https://readers.llmsherpa.com/api/document/developer/parseDocument?renderFormat=all"
        pdf_url = self.location
        pdf_reader = LayoutPDFReader(llmsherpa_api_url)
        doc = pdf_reader.read_pdf(pdf_url)
        print("loading took", time.time() - start)
        return doc

    def create_emb(self, doc):
        start = time.time()
        contexts = []
        for chunk in doc.chunks():
            contexts.append(chunk.to_context_text())
        doc_emb = co.embed(
            contexts, input_type="search_document", model="embed-english-v3.0"
        ).embeddings
        doc_emb = np.asarray(doc_emb)
        print("emb took", time.time() - start)
        self.doc_emb = doc_emb
        self.contexts = contexts
        return doc_emb, contexts

    def ask(self, doc_emb, query, contexts):
        start = time.time()
        query_emb = co.embed(
            [query], input_type="search_query", model="embed-english-v3.0"
        ).embeddings
        query_emb = np.asarray(query_emb)
        query_emb.shape
        scores = np.dot(query_emb, doc_emb.T)[0]
        max_idx = np.argsort(-scores)
        most_relevant_contexts = []
        top_k = 10

        # Get only the top contexts to keep the context for openai small
        for idx in max_idx[0:top_k]:
            most_relevant_contexts.append(contexts[idx])

        passages = "\n".join(most_relevant_contexts)
        prompt = f"Read the following passages and answer the question: {query}\n passages: {passages}"
        completion = co.generate(prompt=prompt)

        # completion = co.chat(message=prompt, model="command", temperature=0.2)
        synthesized_answer = completion[0].text
        print("qa took", time.time() - start)
        return {
            "query": query,
            "answer": synthesized_answer,
            "context": most_relevant_contexts,
        }

    def get_topics(self):
        doc = self.load_doc()
        emb, contexts = self.create_emb(doc)
        prompt = "What are all the topics from the passages? Answer in bullet points"
        response = self.ask(
            emb,
            contexts=contexts,
            query=prompt,
        )
        return response


a = AI("new.pdf")
a.load_doc()
