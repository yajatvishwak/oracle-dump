import streamlit as st
from streamlit_pills import pills
import csv
from md2pdf.core import md2pdf


class st_spinner:  # I know this is a bad class name - I don't want to think of this as a class.
    def __init__(self, text="In progress..."):
        self.text = text
        self._spinner = iter(self._start())  # This creates an infinite spinner
        next(self._spinner)  #  This starts it

    def _start(self):
        with st.spinner(self.text):
            yield

    def end(self):  # This ends it
        next(self._spinner, None)


from ai2 import main


@st.cache_data
def create_pdf(input_pdf=""):
    file = open("prompt/prompts.csv")
    csvreader = csv.reader(file)
    questions = []
    for row in csvreader:
        questions.append(row[0])

    answers = []
    for q in questions:
        answers.append(main(q, pdf_path=input_pdf))
    s = ""
    for q, a in zip(questions, answers):
        s += f"### {q} \n"
        s += f"{a} \n"
        s += f"\n"
    md2pdf("summary.pdf", md_content=s)
    return s


st.title("GRM Bot")

with st.expander(label="Upload files to context"):
    uploaded_file = st.file_uploader(
        "Choose a input pdf file",
    )
    uploaded_file_prompts = st.file_uploader(
        "Choose a prompt file",
    )


if uploaded_file is not None:
    file_path = "docs/" + uploaded_file.name
    if uploaded_file_prompts is not None:
        with open("prompt/prompts.csv", mode="wb") as w:
            w.write(uploaded_file_prompts.getvalue())
        create_pdf(file_path)

        st.download_button(
            "Download summary",
            data=open("summary.pdf", "rb"),
            file_name="summary.pdf",
            mime="application/pdf",
        )

    with open(file_path, mode="wb") as w:
        w.write(uploaded_file.getvalue())

    if "messages" not in st.session_state:
        st.session_state.messages = []

    # Display chat messages from history on app rerun
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.write(message["content"])

    if prompt := st.chat_input("What is up?"):
        # Add user message to chat history
        st.session_state.messages.append({"role": "user", "content": prompt})
        # Display user message in chat message container
        with st.chat_message("user"):
            st.markdown(prompt)

        # Display assistant response in chat message container
        with st.chat_message("assistant"):
            message_placeholder = st.empty()
            s = st_spinner()
            assistant_response = main(prompt, file_path)
            s.end()
            message_placeholder.write(assistant_response)

        # Add assistant response to chat history
        st.session_state.messages.append(
            {"role": "assistant", "content": assistant_response}
        )
