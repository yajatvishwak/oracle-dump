import streamlit as st
from streamlit_pills import pills

from ai import AI
from converter import convert_topic

a = AI("some.pdf")


@st.cache_data
def get_topics():
    topics_str = a.get_topics()
    return convert_topic(topics_str)


with st.sidebar:
    for topic in get_topics():
        with st.container(border=True):
            st.write(topic)
            st.button(label="Know more", key=topic)


st.title("Simple chat")
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display chat messages from history on app rerun
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.write(message["content"])


def truncate_string(input_str, max_length):
    if len(input_str) <= max_length:
        return input_str
    else:
        truncated_str = "..." + input_str[max_length - 3 :]
        return truncated_str


if prompt := st.chat_input("What is up?"):
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    # Display user message in chat message container
    with st.chat_message("user"):
        st.markdown(prompt)

    # Display assistant response in chat message container
    with st.chat_message("assistant"):
        message_placeholder = st.empty()
        full_response = ""
        doc = a.load_doc()
        doc_emb, contexts = a.create_emb(doc)
        response = a.ask(contexts=contexts, doc_emb=doc_emb, query=prompt)
        refs = ""

        assistant_response = f"""
        {response["answer"]}
        """
        newr = []
        message_placeholder.write(assistant_response)
        for r in response["context"]:
            newr.append(truncate_string(r, 50))
        with st.expander("References"):
            selected = pills("References", newr, label_visibility="hidden")
        message_placeholder.write(assistant_response)

    # Add assistant response to chat history
    st.session_state.messages.append({"role": "assistant", "content": full_response})
