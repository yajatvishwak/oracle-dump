from pprint import pprint
import time
import re

import cohere
import numpy as np

cohere_key = "ZSyCsFbScvmLh2lKLnqoVL6VlRmilnLsrDPP7txj"
# Loading the llm model here
# cohere_key = "CL7YaelckE3FI0szoMtLjmCYEPhXBtG8EEIgjGQ3"
llm = cohere.Client(cohere_key)

from pdfminer.pdfparser import PDFParser
from pdfminer.pdfdocument import PDFDocument

from PyPDF2 import PdfReader
from pdfplumber import pdf
from langchain.text_splitter import RecursiveCharacterTextSplitter
from sentence_transformers import SentenceTransformer, util


from numba import jit, cuda


import sys, time, random


def progressBar(count_value, total, suffix=""):
    bar_length = 100
    filled_up_Length = int(round(bar_length * count_value / float(total)))
    percentage = round(100.0 * count_value / float(total), 1)
    bar = "=" * filled_up_Length + "-" * (bar_length - filled_up_Length)
    sys.stdout.write("[%s] %s%s ...%s\r" % (bar, percentage, "%", suffix))
    sys.stdout.flush()


def get_query():
    query = input("Enter your question\n")
    progressBar(1, 5)
    return query


def load_split_pdf(pdf_path):
    pdf_loader = PdfReader(open(pdf_path, "rb"))
    pdf_text = ""
    for page_num in range(len(pdf_loader.pages)):
        pdf_page = pdf_loader.pages[page_num]
        pdf_text += pdf_page.extract_text()
    progressBar(2, 5)

    return pdf_text


def split_text_using_RCTS(pdf_text):
    # text_splitter = RecursiveCharacterTextSplitter(
    #     chunk_size=2048, chunk_overlap=64, separators=["H1", "H2", "H3", "H4"]
    # )
    # split_texts = text_splitter.split_text(pdf_text)
    # paragraphs = []
    # for text in split_texts:
    #     paragraphs.extend(text.split("\n"))
    # progressBar(3, 5)
    # print(paragraphs)
    # return paragraphs
    separators = ["H1", "H2", "H3", "H4"]  # TODO: complete this list of splitters
    # TODO: take care of chunking to avoid going above token limit
    pattern = "|".join(map(re.escape, separators))
    result = re.split(pattern, pdf_text)
    # print(result, len(result))
    return result


def Initialize_sentence_transformer(query, paragraphs):
    start = time.time()
    contexts = []
    for chunk in paragraphs:
        contexts.append(chunk)
    embeddings = llm.embed(
        contexts, input_type="search_document", model="embed-english-v3.0"
    ).embeddings

    print("emb took", time.time() - start, "\n")

    progressBar(4, 5)
    return embeddings


def query_the_llm(embeddings, paragraphs, llm_model, query):
    prompt = f"Extract: {query}\n paragraphs {paragraphs} Do not include any additional information"
    # prompt = f"Extract: {query}\n paragraphs {paragraphs}"
    completion = llm.generate(prompt=prompt, temperature=0.0)

    final_response = completion[0].text

    return final_response


def main(query="", pdf_path=""):
    start_time = time.time()

    # query = get_query()

    # query="List the key topics in the document"

    pdf_text = load_split_pdf(pdf_path)

    paragraphs = split_text_using_RCTS(pdf_text)

    embeddings = Initialize_sentence_transformer(query, paragraphs)

    final_response = query_the_llm(embeddings, paragraphs, llm_model=llm, query=query)

    print("The answer from model is\n", final_response)

    end_time = time.time()
    elapsed_time = end_time - start_time

    print(f"Execution time: {elapsed_time/60} minutes \n")

    progressBar(5, 5)
    return final_response


# main("headings", "new.pdf")
